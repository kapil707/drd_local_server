<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Email_Model extends CI_Model
{
	
	function send_email_message()
	{
		//error_reporting(0);
		$this->db->limit(1);
		$this->db->order_by('id','desc');
		$query = $this->db->get("tbl_email_send")->result();
		
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		print_r($query);
		foreach($query as $row)
		{
			$id 			= $row->id;
			$user_email_id 	= $row->user_email_id;
			$subject 		= base64_decode($row->subject);
			$message 		= base64_decode($row->message);
			$file_name1 	= $row->file_name1;
			$file_name2 	= $row->file_name2;
			$file_name3 	= $row->file_name3;
			$file_name_1 	= $row->file_name_1;
			$file_name_2 	= $row->file_name_2;
			$file_name_3 	= $row->file_name_3;
			$mail_server 	= $row->mail_server;
			$email_other_bcc= $row->email_other_bcc;
			if($row->email_other_bcc=="")
			{
				$email_other_bcc="";
			}
			
			$addreplyto 		= "vipul@drdindia.com";
			$addreplyto_name 	= "Vipul DRD";
			$server_email 		= "send@drdindia.com";
			$server_email_name 	= "DRD Report";
			$email1 			= "kapil707sharma@gmail.com";
			$email_bcc 			= "kapil7071@gmail.com";
			
			$email->AddReplyTo($addreplyto,$addreplyto_name);
			$email->SetFrom($server_email,$server_email_name);
			$email->AddAddress($user_email_id);
			
			$email->Subject   	= $subject;
			$email->Body 		= $message;		
			
			$email->IsHTML(true);
			/*if($live_or_demo=="Demo")
			{
				$email->AddAddress($mail_server);
				$email_other_bcc = explode (",", $email_other_bcc);
				foreach($email_other_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}
			else
			{
				$email->AddAddress($mail_server);
				//$email->addBcc($mail_server);
				$email_other_bcc = explode (",", $email_other_bcc);
				foreach($email_other_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}*/
			if($file_name1)
			{
				if($file_name_1)
				{
					$email->addAttachment($file_name1,$file_name_1);
				}
				else
				{
					$email->addAttachment($file_name1);
				}
			}
			if($file_name2)
			{
				if($file_name_2)
				{
					$email->addAttachment($file_name2,$file_name_2);
				}
				else
				{
					$email->addAttachment($file_name2);
				}
			}
			if($file_name3)
			{
				if($file_name_3)
				{
					$email->addAttachment($file_name3,$file_name_3);
				}
				else
				{
					$email->addAttachment($file_name3);
				}
			}
			
			/************************************************/
			$this->db->query("delete from tbl_email_send where id='$id'");
			/************************************************/

			$email->IsSMTP();
			$email->SMTPAuth   = true; 
			$email->SMTPSecure = "tls";  //tls
			$email->Host       = "smtpcorp.com";
			$email->Port       = 2525;
			$email->Username   = "send@drdindia.com";
			$email->Password   = "DRD#123";
			if($email->Send()){
				echo "Mail Sent";
			}
			else{
				echo "Mail Failed";
			}
			if($file_name1)
			{
				unlink($file_name1);
			}
			if($file_name2)
			{
				unlink($file_name2);
			}
			if($file_name3)
			{
				unlink($file_name3);
			}
		}
	}
}