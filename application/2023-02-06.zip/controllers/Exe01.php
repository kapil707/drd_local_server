<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Exe01 extends CI_Controller 
{
	public function download_query_for_local_server()
	{
		$isdone	= "";
		$data 	= json_decode(file_get_contents('php://input'), true);
        $items 	= $data["items"];
		foreach ($items as $row) {
			if (!empty($row["query_type"])) {

				if ($row["query_type"] == "order_download") {

					$online_id 		= $row["online_id"];
					$order_id 		= $row["order_id"];
					$i_code			= $row["i_code"];
					$item_code 		= $row["item_code"];
					$quantity 		= $row["quantity"];
					$user_type 		= $row["user_type"];
					$chemist_id 	= $row["chemist_id"];
					$salesman_id 	= $row["salesman_id"];
					$acno 			= $row["acno"];
					$slcd 			= $row["slcd"];
					$sale_rate 		= $row["sale_rate"];
					$remarks 		= base64_decode($row["remarks"]);
					$date 			= $row["date"];
					$time 			= $row["time"];
					$total_line 	= $row["total_line"];
					$temp_rec 		= $row["temp_rec"];
					$new_temp_rec 	= $row["new_temp_rec"];
					$order_status 	= $row["order_status"];

					$dt = array(
						'online_id'=>$online_id,
						'order_id'=>$order_id,
						'i_code'=>$i_code,
						'item_code'=>$item_code,
						'quantity'=>$quantity,
						'sale_rate'=>$sale_rate,
						'user_type'=>$user_type,
						'chemist_id'=>$chemist_id,
						'salesman_id'=>$salesman_id,
						'acno'=>$acno,
						'slcd'=>$slcd,
						'remarks'=>$remarks,
						'date'=>$date,
						'time'=>$time,
						'total_line'=>$total_line,
						'temp_rec'=>$temp_rec,
						'new_temp_rec'=>$new_temp_rec,
						'order_status'=>$order_status,
						'gstvno'=>'',
					);
					$row1 = $this->db->query("select online_id from tbl_order_download where online_id='" . $online_id . "' order by id desc")->row();
					if (empty($row1->online_id)) {
						$this->Scheme_Model->insert_fun("tbl_order_download", $dt);
					} else {
						$where = array('online_id' => $online_id);
						$this->Scheme_Model->edit_fun("tbl_order_download", $dt, $where);
					}
					$isdone = "yes";
				}

				if ($row["query_type"] == "medicine_image") {
					$itemid 	= $row["itemid"];
					$featured 	= $row["featured"];
					$image 		= $row["image"];
					$image2 	= $row["image2"];
					$image3 	= $row["image3"];
					$image4 	= $row["image4"];
					$title 		= $row["title"];
					$description= $row["description"];
					$status 	= $row["status"];
					$date 		= $row["date"];
					$time 		= $row["time"];

					$title = base64_decode($title);
					$description = base64_decode($description);

					$dt = array(
						'itemid'=>$itemid,
						'featured'=>$featured,
						'image'=>$image,
						'image2'=>$image2,
						'image3'=>$image3,
						'image4'=>$image4,
						'title'=>$title,
						'description'=>$description,
						'status'=>$status,
						'date'=>$date,
						'time'=>$time,
					);

					if (!empty($itemid)) {
						$row1 = $this->db->query("select itemid from tbl_medicine_image where itemid='" . $itemid . "' order by id desc")->row();
						if (empty($row1->itemid)) {
							$this->Scheme_Model->insert_fun("tbl_medicine_image", $dt);
						} else {
							$where = array('itemid' => $itemid);
							$this->Scheme_Model->edit_fun("tbl_medicine_image", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "acm_other") {

					$code 			= $row["code"];
					$status 		= $row["status"];
					$exp_date 		= $row["exp_date"];
					$password 		= $row["password"];
					$broadcast 		= $row["broadcast"];
					$block 			= $row["block"];
					$image 			= $row["image"];
					$user_phone 	= $row["user_phone"];
					$user_email 	= $row["user_email"];
					$user_address 	= $row["user_address"];
					$user_update 	= $row["user_update"];
					$order_limit 	= $row["order_limit"];
					$new_request 	= $row["new_request"];
					$website_limit 	= $row["website_limit"];
					$android_limit 	= $row["android_limit"];

					$user_address 	= base64_decode($user_address);

					$dt = array(
						'code'=>$code,
						'status'=>$status,
						'exp_date'=>$exp_date,
						'password'=>$password,
						'broadcast'=>$broadcast,
						'image'=>$image,
						'block'=>$block,
						'user_phone'=>$user_phone,
						'user_email'=>$user_email,
						'user_address'=>$user_address,
						'user_update'=>$user_update,
						'order_limit'=>$order_limit,
						'new_request'=>$new_request,
						'website_limit'=>$website_limit,
						'android_limit'=>$android_limit,
					);

					if (!empty($row["code"])) {
						$row1 = $this->db->query("select code from tbl_acm_other where code='" . $code . "' order by id desc")->row();
						if (empty($row1->code)) {
							$this->Scheme_Model->insert_fun("tbl_acm_other", $dt);
						} else {
							$where = array('code'=>$code);
							$this->Scheme_Model->edit_fun("tbl_acm_other", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "staffdetail_other") {

					$code 				= $row["code"];
					$status 			= $row["status"];
					$password 			= $row["password"];
					$daily_date 		= $row["daily_date"];
					$monthly 			= $row["monthly"];
					$whatsapp_message 	= $row["whatsapp_message"];
					$item_wise_report 	= $row["item_wise_report"];
					$chemist_wise_report= $row["chemist_wise_report"];
					$stock_and_sales_analysis = $row["stock_and_sales_analysis"];
					$item_wise_report_daily_email = $row["item_wise_report_daily_email"];
					$chemist_wise_report_daily_email = $row["chemist_wise_report_daily_email"];
					$stock_and_sales_analysis_daily_email = $row["stock_and_sales_analysis_daily_email"];
					$item_wise_report_monthly_email = $row["item_wise_report_monthly_email"];
					$chemist_wise_report_monthly_email = $row["chemist_wise_report_monthly_email"];

					$dt = array(
						'code'=>$code,
						'status'=>$status,
						'password'=>$password,
						'daily_date'=>$daily_date,
						'monthly'=>$monthly,
						'whatsapp_message'=>$whatsapp_message,
						'item_wise_report'=>$item_wise_report,
						'chemist_wise_report'=>$chemist_wise_report,
						'stock_and_sales_analysis'=>$stock_and_sales_analysis,
						'item_wise_report_daily_email'=>$item_wise_report_daily_email,	'chemist_wise_report_daily_email'=>$chemist_wise_report_daily_email,
						'stock_and_sales_analysis_daily_email'=>$stock_and_sales_analysis_daily_email,
						'item_wise_report_monthly_email'=>$item_wise_report_monthly_email,
						'chemist_wise_report_monthly_email'=>$chemist_wise_report_monthly_email,
						'status2'=>0,
					);

					if (!empty($row["code"])) {
						$row1 = $this->db->query("select code from tbl_staffdetail_other where code='" . $code . "' order by id desc")->row();
						if (empty($row1->code)) {
							$this->Scheme_Model->insert_fun("tbl_staffdetail_other", $dt);
						} else {
							$where = array('code'=>$code);
							$this->Scheme_Model->edit_fun("tbl_staffdetail_other", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "low_stock_alert") {

					$vdt 	= $row["vdt"];
					$acno 	= $row["acno"];
					$slcd 	= $row["slcd"];
					$itemc 	= $row["itemc"];
					$uid 	= $row["uid"];

					$this->Drd_Order_Model->insert_shortage($vdt, $acno, $slcd, $itemc, $uid);
					$isdone = "yes";
				}
			}
		}

		if($isdone=="yes")
		{
			echo "done";
		}
	}

	/*************order download*************/
	public function insert_order_in_localhost()
	{		
		/*
		$curl = curl_init();
		$parmiter = "";
		curl_setopt_array(
		$curl,
			array(
				CURLOPT_URL => 'https://drdweb.co.in/exe01/test/download_order_in_localhost',
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => '',
				CURLOPT_MAXREDIRS => 0,
				CURLOPT_TIMEOUT => 10,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS => $parmiter,
				CURLOPT_HTTPHEADER => array(
					'Content-Type: application/json',
				),
			)
		);
		$response = curl_exec($curl);
		curl_close($curl);
		$json = json_decode($response, true);
		if(!empty($json["items"])){
			foreach($json["items"] as $row){
				$online_id 		= $row["online_id"];
				$order_id 		= $row["order_id"];
				$i_code 		= $row["i_code"];
				$item_code 		= $row["item_code"];
				$quantity 		= $row["quantity"];
				$sale_rate 		= $row["sale_rate"];
				$user_type 		= $row["user_type"];
				$chemist_id 	= $row["chemist_id"];
				$salesman_id 	= $row["salesman_id"];
				$acno 			= $row["acno"];
				$slcd 			= $row["slcd"];
				$remarks 		= base64_decode($row["remarks"]);
				$date 			= $row["date"];
				$time 			= $row["time"];
				$total_line 	= $row["total_line"];
				$temp_rec 		= $row["temp_rec"];
				$new_temp_rec 	= $row["new_temp_rec"];
				$order_status 	= $row["order_status"];
				
				$dt = array(
					'online_id'=>$online_id,
					'order_id'=>$order_id,
					'i_code'=>$i_code,
					'item_code'=>$item_code,
					'quantity'=>$quantity,
					'sale_rate'=>$sale_rate,
					'user_type'=>$user_type,
					'chemist_id'=>$chemist_id,
					'salesman_id'=>$salesman_id,
					'acno'=>$acno,
					'slcd'=>$slcd,
					'remarks'=>$remarks,
					'date'=>$date,
					'time'=>$time,
					'total_line'=>$total_line,
					'temp_rec'=>$temp_rec,
					'new_temp_rec'=>$new_temp_rec,
					'order_status'=>$order_status,
				);
				$row1 = $this->db->query("select online_id from tbl_order_download where online_id='" . $online_id . "' order by id desc")->row();
				if (empty($row1->online_id)) {
					$this->Scheme_Model->insert_fun("tbl_order_download", $dt);
				} else {
					$where = array('online_id' => $online_id);
					$this->Scheme_Model->edit_fun("tbl_order_download", $dt, $where);
				}
			}
		}*/
	}
	public function order_process()
	{
		$this->insert_order_to_eseysol();
		$this->check_order_to_gstvno_update();
	}
	
	
	public function insert_order_to_eseysol()
	{
		echo "work---";
		$row0 = $this->db->query("select DISTINCT(temp_rec) from tbl_order_download where order_status=0 order by id asc limit 1")->row();
		if (!empty($row0->temp_rec)) {
			echo $temp_rec = $row0->temp_rec;
		}
		if (!empty($temp_rec)) {
			$row = $this->db->query("select total_line,count(id) as ct,order_id from tbl_order_download where temp_rec='$temp_rec'")->row();
			if ($row->ct == $row->total_line) {				
				$this->insert_order_to_eseysol_with_id($temp_rec);
			}else{
				
				$order_id = $row->order_id;
				
				echo $message = "Error order line items Order No. : ".$order_id." Get line items : ".$row->ct." Total Line Items : ".$row->total_line;

				$group_message = $group2_message = $message;

				$whatsapp_group = "919899333989-1567708298@g.us";
				$this->Message_Model->insert_whatsapp_group_message($whatsapp_group, $group_message);

				$whatsapp_group2 = "919899333989-1628519476@g.us";
				$this->Message_Model->insert_whatsapp_group_message($whatsapp_group2, $group2_message);

				$items.='{"order_id":"'.$order_id.'"}';

				$curl = curl_init();
				$parmiter = '{"items": ['.$items.']}';
				curl_setopt_array(
				$curl,
					array(
						CURLOPT_URL => 'https://drdweb.co.in/exe01/exe02/download_order_again',
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => '',
						CURLOPT_MAXREDIRS => 0,
						CURLOPT_TIMEOUT => 10,
						CURLOPT_FOLLOWLOCATION => true,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => 'POST',
						CURLOPT_POSTFIELDS => $parmiter,
						CURLOPT_HTTPHEADER => array(
							'Content-Type: application/json',
						),
					)
				);

				$response = curl_exec($curl);

				curl_close($curl);
				echo $response;
			}
		}
	}

	public function insert_order_to_eseysol_with_id($temp_rec='') {
		
		$row = $this->db->query("select order_id,new_temp_rec,date,time,chemist_id,remarks,acno,slcd from tbl_order_download where temp_rec='".$temp_rec."' limit 1")->row();
		
		$order_id 		= $row->order_id;
		$uid 			= "DRD-".$order_id;
		$PorderCount_yes_no = $this->Drd_Order_Model->get_order_PorderCount($uid);
		if (empty($PorderCount_yes_no)) {
			if (!empty($order_id)) {
					
				/*************************************/
				$order_no = $this->Drd_Order_Model->get_PorderCount_ordno();
				/*************************************/

				/********************************* */
				echo $message = "This Order No. *" . $order_id . "* downloaded and inserted to easysol properly. Easysol Order No. *" . $order_no . "*";

				if (!empty($remarks)) {
					$message = $message . " Remarks : " . $remarks;
				}

				$group_message = $group2_message = $message;

				$whatsapp_group = "919899333989-1567708298@g.us";
				$this->Message_Model->insert_whatsapp_group_message($whatsapp_group, $group_message);

				$whatsapp_group2 = "919899333989-1628519476@g.us";
				$this->Message_Model->insert_whatsapp_group_message($whatsapp_group2, $group2_message);

				/****************************************************** */

				$date	 	= $row->date;
				$time 		= $row->time;
				$remarks 	= $row->remarks;
				$acno 		= $row->acno;
				$slcd 		= $row->slcd;
				
				if(empty($acno)){
					$v = $this->Drd_Order_Model->get_order_acm($row->chemist_id);
					$acno = $v["acno"];
					$slcd = $v["slcd"];
				}

				$ordtype 	= "DRD";
				$odt 		= $date; //get_today_date();
				$mtime 		= $time; //get_now_time();
				$downloaddate = $date; //get_today_date();
				$dayenddate = $date; //get_today_date();

				/********************************************/
				$this->Drd_Order_Model->insert_order_PorderCount($order_no, $uid, $odt, $acno, $ordtype, $mtime, $downloaddate, $dayenddate, $remarks);
				/********************************************/

			}
		} else {
			$order_no = $PorderCount_yes_no; // order no ata ha jab dubara order add honay lagta ha to oss time
		}
		$Porder_yes_no = $this->Drd_Order_Model->get_order_Porder($uid);
		if (empty($Porder_yes_no)) {
			if (!empty($order_id)) {
				$result = $this->db->query("select * from tbl_order_download where order_id='$order_id'")->result();
				foreach ($result as $row) {
					
					$date = $row->date;
					$time = $row->time;
					
					$odt 		= $date; //get_today_date();
					$mtime 		= $time; //get_now_time();
					$downloaddate = $date; //get_today_date();
					$dayenddate = $date; //get_today_date();
					
					$itemc 		= $row->i_code;
					$qty 		= $row->quantity;
					$mrp 		= $row->sale_rate;
					$id 		= $row->id;
					$acno 		= $row->acno;
					$slcd 		= $row->slcd;
					$remarks 	= $row->remarks;
					
					if(empty($acno)){
						$v = $this->Drd_Order_Model->get_order_acm($row->chemist_id);
						$acno = $v["acno"];
						$slcd = $v["slcd"];
					}

					/********************************************/
					$this->Drd_Order_Model->insert_order_Porder($slcd, $acno, $odt, $itemc, $qty, $order_no, $uid, $mtime, $mrp, $remarks);
					/********************************************/

					/********************************************/
					$this->db->query("update tbl_order_download set order_status='1',ordno_new='" . $order_no . "' where order_status='0' and id='" . $id . "'");
					/********************************************/
				}
			}
		}
		if (!empty($PorderCount_yes_no) && !empty($Porder_yes_no)) {
			/********************************* */
			echo $message = "Error duplicate order create " . $order_id;

			if (!empty($remarks)) {
				$message = $message . " Remarks : " . $remarks;
			}

			$group_message = $group2_message = $message;

			$whatsapp_group = "919899333989-1567708298@g.us";
			$this->Message_Model->insert_whatsapp_group_message($whatsapp_group, $group_message);

			$whatsapp_group2 = "919899333989-1628519476@g.us";
			$this->Message_Model->insert_whatsapp_group_message($whatsapp_group2, $group2_message);

			/****************************************************** */
		}
	}

	public function check_order_to_gstvno_update()
	{
		$result = $this->db->query("SELECT DISTINCT ordno_new from tbl_order_download where order_status='1' and gstvno='' ORDER BY RAND() limit 1")->result();
		foreach($result as $row){
			$ordno_new 	= $row->ordno_new;
			$result1 	= $this->Drd_Order_Model->get_gstvno_in_pordercount($ordno_new);
			foreach($result1 as $row1){
				$tag 		= $row1->tag;
                $purvtype 	= $row1->purvtype;
                $purvno 	= $row1->purvno;
                $purvdt 	= $row1->purvdt;
                
				if ($tag == "Y") {
					$result2 = $this->Drd_Order_Model->get_gstvno_in_salepurchase($ordno_new, $purvtype,$purvno,$purvdt);
					foreach($result2 as $row2) {
						$gstvno 	= $row2->gstvno;
						$this->db->query("update tbl_order_download set order_status='2',gstvno='$gstvno' where order_status='1' and ordno_new='$ordno_new'");
					}
				}

				if ($tag == "D") {
					//jab order nahi insert to hua esey sol me but delete kar diya to yha chalay ge
					$gstvno = "0000";
					$this->db->query("update tbl_order_download set order_status='2',gstvno='$gstvno' where order_status='1' and ordno_new='$ordno_new'");
				}
			}
		}
	}
}