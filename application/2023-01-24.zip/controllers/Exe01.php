<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Exe01 extends CI_Controller 
{
	public function download_query_for_local_server()
	{
		$isdone	= "";
		$data 	= json_decode(file_get_contents('php://input'), true);
        $items 	= $data["items"];
		foreach ($items as $row) {
			if (!empty($row["query_type"])) {
				if ($row["query_type"] == "medicine_image") {
					$itemid = $row["itemid"];
					$featured = $row["featured"];
					$image = $row["image"];
					$image2 = $row["image2"];
					$image3 = $row["image3"];
					$image4 = $row["image4"];
					$title = $row["title"];
					$description = $row["description"];
					$status = $row["status"];
					$date = $row["date"];
					$time = $row["time"];

					$title = base64_decode($title);
					$description = base64_decode($description);

					$dt = array(
						'itemid' => $itemid,
						'featured' => $featured,
						'image' => $image,
						'image2' => $image2,
						'image3' => $image3,
						'image4' => $image4,
						'title' => $title,
						'description' => $description,
						'status' => $status,
						'date' => $date,
						'time' => $time,
					);

					if (!empty($itemid)) {
						$row1 = $this->db->query("select itemid from tbl_medicine_image where itemid='" . $itemid . "' order by id desc")->row();
						if (empty($row1->itemid)) {
							$this->Scheme_Model->insert_fun("tbl_medicine_image", $dt);
						} else {
							$where = array('itemid' => $itemid);
							$this->Scheme_Model->edit_fun("tbl_medicine_image", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "acm_other") {

					$code 			= $row["code"];
					$status 		= $row["status"];
					$exp_date 		= $row["exp_date"];
					$password 		= $row["password"];
					$broadcast 		= $row["broadcast"];
					$block 			= $row["block"];
					$image 			= $row["image"];
					$user_phone 	= $row["user_phone"];
					$user_email 	= $row["user_email"];
					$user_address 	= $row["user_address"];
					$user_update 	= $row["user_update"];
					$order_limit 	= $row["order_limit"];
					$new_request 	= $row["new_request"];
					$website_limit 	= $row["website_limit"];
					$android_limit 	= $row["android_limit"];

					$user_address 	= base64_decode($user_address);

					$dt = array(
						'code' =>$code,
						'status' =>$status,
						'exp_date' =>$exp_date,
						'password' =>$password,
						'broadcast' =>$broadcast,
						'image' =>$image,
						'block' =>$block,
						'user_phone' =>$user_phone,
						'user_email' =>$user_email,
						'user_address' =>$user_address,
						'user_update' =>$user_update,
						'order_limit' =>$order_limit,
						'new_request' =>$new_request,
						'website_limit' =>$website_limit,
						'android_limit' =>$android_limit,
					);

					if (!empty($row["code"])) {
						$row1 = $this->db->query("select code from tbl_acm_other where code='" . $code . "' order by id desc")->row();
						if (empty($row1->code)) {
							$this->Scheme_Model->insert_fun("tbl_acm_other", $dt);
						} else {
							$where = array('code'=>$code);
							$this->Scheme_Model->edit_fun("tbl_acm_other", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "staffdetail_other") {

					$code 			= $row["code"];
					$status 		= $row["status"];
					$password 		= $row["password"];
					$daily_date 	= $row["daily_date"];
					$monthly 		= $row["monthly"];
					$whatsapp_message 	= $row["whatsapp_message"];
					$item_wise_report 	= $row["item_wise_report"];
					$chemist_wise_report = $row["chemist_wise_report"];
					$stock_and_sales_analysis = $row["stock_and_sales_analysis"];
					$item_wise_report_daily_email = $row["item_wise_report_daily_email"];
					$chemist_wise_report_daily_email = $row["chemist_wise_report_daily_email"];
					$stock_and_sales_analysis_daily_email = $row["stock_and_sales_analysis_daily_email"];
					$item_wise_report_monthly_email = $row["item_wise_report_monthly_email"];
					$chemist_wise_report_monthly_email = $row["chemist_wise_report_monthly_email"];

					$dt = array(
						'code' =>$code,
						'status' =>$status,
						'password' =>$password,
						'daily_date' =>$daily_date,
						'monthly' =>$monthly,
						'whatsapp_message' =>$whatsapp_message,
						'item_wise_report' =>$item_wise_report,
						'chemist_wise_report' =>$chemist_wise_report,
						'stock_and_sales_analysis' =>$stock_and_sales_analysis,
						'item_wise_report_daily_email' =>$item_wise_report_daily_email,
						'chemist_wise_report_daily_email' =>$chemist_wise_report_daily_email,
						'stock_and_sales_analysis_daily_email' =>$stock_and_sales_analysis_daily_email,
						'item_wise_report_monthly_email' =>$item_wise_report_monthly_email,
						'chemist_wise_report_monthly_email' =>$chemist_wise_report_monthly_email,'status2' =>0,
					);

					if (!empty($row["code"])) {
						$row1 = $this->db->query("select code from tbl_staffdetail_other where code='" . $code . "' order by id desc")->row();
						if (empty($row1->code)) {
							$this->Scheme_Model->insert_fun("tbl_staffdetail_other", $dt);
						} else {
							$where = array('code'=>$code);
							$this->Scheme_Model->edit_fun("tbl_staffdetail_other", $dt, $where);
						}
						$isdone = "yes";
					}
				}

				if ($row["query_type"] == "low_stock_alert") {

					$vdt = $row["vdt"];
					$acno = $row["acno"];
					$slcd = $row["slcd"];
					$itemc = $row["itemc"];
					$uid = $row["uid"];

					$this->Drd_Order_Model->insert_shortage($vdt, $acno, $slcd, $itemc, $uid);
					$isdone = "yes";
				}
			}
		}

		if($isdone=="yes")
		{
			echo "done";
		}
	}
}