<div class="row">
    <div class="col-xs-4" style="margin-bottom:5px;">
		<form class="form-horizontal" role="form" method="get" enctype="multipart/form-data">
			<select name="table_name" id="table_name" data-placeholder="Select Status" class="chosen-select" required="required" onchange='this.form.submit()'>
				<?php 
				foreach (range('a', 'z') as $alphabet) { ?>
				<option value="<?= $alphabet; ?>_med" <?php if($_GET["table_name"]==$alphabet."_med") { ?> selected <?php } ?>>
					<?= strtoupper($alphabet); ?>
				</option>
				<?php } ?>
			</select>
		</form>
   	</div>
    <div class="col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover dataTables-example">
                <thead>
                    <tr>
                    	<th>
                        	Sno.
                        </th>
						<th width="300px">
                        	Medicine Name / Essysol Name
                        </th>
						<th>
                        	Description
                        </th>
                        <th width="100px;">
                        	Image
                        </th>
                        <th>
                        	Action
                        </th>
                    </tr>
                </thead>

                <tbody>
                <?php
				$i=1;
                foreach ($result as $row)
                {
					?>
                    <tr id="row_<?= $row->id; ?>">
                    	<td>
                        	<?= $i++; ?>
                        </td>
 						<td>
                        	<?= ($row->itemname); ?>
							<br>
                        	<input type="text" class="form-control">
                        </td>
						<td>
                        	<?= ($row->a1); ?>
                        </td>
                        <td>
							<?php
							$url = "http://drdistributor.com/medicine_images/";
							if($row->update_url==0)
							{
								$img1 = $url.$row->table_name."/".$row->img1;
								$img2 = $url.$row->table_name."/".$row->img2;
								$img3 = $url.$row->table_name."/".$row->img3;
								$img4 = $url.$row->table_name."/".$row->img4;
							}
							else
							{
								$img1 = $row->img1;
								$img2 = $row->img2;
								$img3 = $row->img3;
								$img4 = $row->img4;
							}
							?>
							<img src="<?= ($img1); ?>" width="100">
							<input type="hidden" class="a1_<?= $row->id; ?>" value="<?= $row->a1; ?>">
							<input type="hidden" class="a5_<?= $row->id; ?>" value="<?= $row->a5; ?>">
							<input type="hidden" class="img1_<?= $row->id; ?>" value="<?= ($img1); ?>">
							<input type="hidden" class="img1_<?= $row->id; ?>" value="<?= ($img1); ?>">
							<input type="hidden" class="img2_<?= $row->id; ?>" value="<?= ($img2); ?>">
							<input type="hidden" class="img3_<?= $row->id; ?>" value="<?= ($img3); ?>">
							<input type="hidden" class="img4_<?= $row->id; ?>" value="<?= ($img4); ?>">
                        </td>
						<td class="text-right">
							<div class="btn-group">
								<a href="javascript:void(0)" onclick="edit_rec('<?= $row->id; ?>')" class="btn-white btn btn-xs">Edit</i> </a>
								<a href="javascript:void(0)" onclick="delete_rec('<?= $row->id; ?>')" class="btn-white btn btn-xs">Delete</i> </a>
							</div>
                        </td> 
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<button type="button" data-toggle="modal" data-target="#myModal" id="modal_open" style="display:none"></button>
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Edit</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<div class="row">
						<div class="col-sm-2">
							<label class="control-label" for="form-field-1">
								Image 1
							</label>
						</div>
						<div class="col-sm-8">
							<input type="text" class="form-control model_img1" onchange="onchange_model_img1()">
						</div>
						<div class="col-sm-2">
							<img src="" width="100%" class="model_s_img1">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-2">
							<label class="control-label" for="form-field-1">
								Image 2
							</label>
						</div>
						<div class="col-sm-8">
							<input type="text" class="form-control model_img2" onchange="onchange_model_img2()">
						</div>
						<div class="col-sm-2">
							<img src="" width="100%" class="model_s_img2">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-2">
							<label class="control-label" for="form-field-1">
								Image 3
							</label>
						</div>
						<div class="col-sm-8">
							<input type="text" class="form-control model_img3" onchange="onchange_model_img3()">
						</div>
						<div class="col-sm-2">
							<img src="" width="100%" class="model_s_img3">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-2">
							<label class="control-label" for="form-field-1">
								Image 4
							</label>
						</div>
						<div class="col-sm-8">
							<input type="text" class="form-control model_img4" onchange="onchange_model_img4()">
						</div>
						<div class="col-sm-2">
							<img src="" width="100%" class="model_s_img4">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-3">
							<label class="control-label" for="form-field-1">
								Description 1
							</label>
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control model_a1">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-3">
							<label class="control-label" for="form-field-1">
								Description 2
							</label>
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control model_a5">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-12">
							<input type="hidden" class="update_id">
							<button type="button" class="btn btn-primary btn-lg" onclick="update_rec()">Update</button>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
			<button type="button" class="btn btn-default close_model" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<script>
var delete_rec1 = 0;
function delete_rec(id)
{
	if (confirm('Are you sure Delete?')) { 
	if(delete_rec1==0)
	{
		delete_rec1 = 1;
		$.ajax({
			type       : "POST",
			data       :  {id:id,},
			url        : "<?= base_url()?>admin/<?= $Page_name; ?>/delete_rec",
			success    : function(data){
					if(data!="")
					{
						$("#row_"+id).hide("500");
						java_alert_function("success","Delete Successfully");
					}					
					else
					{
						java_alert_function("error","Something Wrong")
					}
					delete_rec1 = 0;
				}
			});
		}
	}
}
function edit_rec(id)
{
	$("#modal_open").click();
	$(".update_id").val(id);
	img1 = $(".img1_"+id).val();
	img2 = $(".img2_"+id).val();
	img3 = $(".img3_"+id).val();
	img4 = $(".img4_"+id).val();
	a1 = $(".a1_"+id).val();
	a5 = $(".a5_"+id).val();
	$(".model_img1").val(img1);
	$(".model_img2").val(img2);
	$(".model_img3").val(img3);
	$(".model_img4").val(img4);
	
	$(".model_a1").val(a1);
	$(".model_a5").val(a5);
	
	$(".model_s_img1").attr("src",img1);
	$(".model_s_img2").attr("src",img2);
	$(".model_s_img3").attr("src",img3);
	$(".model_s_img4").attr("src",img4);
}
function update_rec()
{
	id   = $(".update_id").val();
	img1 = $(".model_img1").val();
	img2 = $(".model_img2").val();
	img3 = $(".model_img3").val();
	img4 = $(".model_img4").val();
	a1   = $(".model_a1").val();
	a5   = $(".model_a5").val();
	
	$.ajax({
	type       : "POST",
	data       :  {id:id,img1:img1,img2:img2,img3:img3,img4:img4,a1:a1,a5:a5,},
	url        : "<?= base_url()?>admin/<?= $Page_name; ?>/update_rec",
	success    : function(data){
			if(data!="")
			{
				java_alert_function("success","Update Successfully");
			}					
			else
			{
				java_alert_function("error","Something Wrong")
			}
			$(".close_model").click();
			delete_rec1 = 0;
		}
	});
}
function onchange_model_img1()
{
	img1 = $(".model_img1").val();
	$(".model_s_img1").attr("src",img1);
}
function onchange_model_img2()
{
	img2 = $(".model_img2").val();
	$(".model_s_img2").attr("src",img2);
}
function onchange_model_img3()
{
	img3 = $(".model_img3").val();
	$(".model_s_img3").attr("src",img3);
}
function onchange_model_img4()
{
	img4 = $(".model_img4").val();
	$(".model_s_img4").attr("src",img4);
}
</script>