<script>
window.location.href = "admin"
</script>