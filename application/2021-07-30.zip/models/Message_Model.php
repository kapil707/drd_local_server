<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Message_Model extends CI_Model
{
	public function tbl_whatsapp_email_fail($number,$message,$altercode)
	{
		$where = array('altercode'=>$altercode);
		$row = $this->Scheme_Model->select_row("tbl_whatsapp_email_fail",$where,'','');
		if($row->id=="")
		{
			$this->db->query("insert into tbl_whatsapp_email_fail set altercode='$altercode',mobile='$number',message='$message'");
		}
	}
	
	public function insert_whatsapp_message($mobile,$message,$altercode)
	{
		$time = time();
		$date = date("Y-m-d",$time);

		$dt = array(
		'mobile'=>$mobile,
		'message'=>base64_encode($message),
		'chemist_id'=>$altercode,
		'time'=>$time,
		'date'=>$date,
		);
		$this->Scheme_Model->insert_fun("tbl_whatsapp_message",$dt);
	}
	
	public function send_whatsapp_message()
	{		
		$whatsapp_key = "531fe5caf0e132bdb6000bf01ed66d8cfb75b53606cc8f6eed32509d99d74752f47f288db155557e";
		
		$this->db->limit(50);
		$query = $this->db->get("tbl_whatsapp_message")->result();
		foreach($query as $row)
		{
			$mid 			= $row->id;
			$mobile 		= $row->mobile;
			$media 			= $row->media;
			$message 		= base64_decode($row->message);
			$message 		= str_replace("<br>","\\n \\n",$message);
			
			$chemist_id 	= $row->chemist_id;
			$this->db->query("DELETE FROM `tbl_whatsapp_message` WHERE id='$mid'");
		
			if($media!="")
			{
				$parmiter = '{"phone": "'.$mobile.'","message": "'.$message.'","media": { "file": "'.$media.'" }}';
			}
			if($media=="")
			{
				$parmiter = "{\"phone\":\"$mobile\",\"message\":\"$message\"}";
			}

			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => "https://api.wassi.chat/v1/messages",
			CURLOPT_RETURNTRANSFER=>true,
			CURLOPT_ENCODING =>"",
			CURLOPT_MAXREDIRS =>10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION =>CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS =>$parmiter,
			CURLOPT_HTTPHEADER =>array("content-type: application/json","token:$whatsapp_key"),));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				echo "cURL Error #:" . $err;
				$err = "Number stored is : $mobile";
				$this->Message_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			} else {
				//echo $response;
				$someArray = json_decode($response,true);
				if($someArray["status"]=="400"||$someArray["status"]=="401"||$someArray["status"]=="409"||$someArray["status"]=="500"||$someArray["status"]=="501"||$someArray["status"]=="503")
				{
					$err = "Number stored is : $mobile";
					$this->Message_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
				}
			}
		}
	}
}