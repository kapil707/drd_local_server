<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Cronjob_page extends CI_Controller 
{
	public function test_email()
	{
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		
		$subject = "drd local test";
		$message = "drd local test";
		
		$addreplyto 		= "vipul@drdindia.com";
		$addreplyto_name 	= "Vipul DRD";
		$server_email 		= "kapil707sharma@gmail.com";
		$server_email_name 	= "kapil";
		$email1 			= "kapil707sharma@gmail.com";
		$email_bcc 			= "kapil7071@gmail.com";
		
		$email->AddReplyTo($addreplyto,$addreplyto_name);
		$email->SetFrom($server_email,$server_email_name);
		$email->AddAddress($email1);
		
		$email->Subject   	= $subject;
		$email->Body 		= $message;		
		
		$email->IsHTML(true);	

		$email->IsSMTP();
		$email->SMTPAuth   = true; 
		$email->SMTPSecure = "tls";  //tls
		$email->Host       = "smtpcorp.com";
		$email->Port       = 2525;
		$email->Username   = "send@drdindia.com";
		$email->Password   = "DRD#123";
		
		if($email->Send()){
			echo "Mail Sent";
		}
	}
	
	public function test_corporate()
	{
		//$this->load->view('corporate/header');
		$this->load->view("home/test_corporate");
	}
	
	public function test_corporate1()
	{
		//$this->load->view('corporate/header');
		$this->load->view("home/test_corporate1");
	}
	
	
	public function pendingorder_email(){
		$query = $this->db->query("select DISTINCT barcode,MAX(qty) as qty,itemc,name,pack,division,company_full_name,uname,uemail,umobile,acno,id from tbl_pending_order where acno=(SELECT acno FROM `tbl_pending_order` WHERE status=1 and uemail!='' order by acno limit 1) group by barcode order by division asc");
		$result = $query->result();
		$row = $query->row();
		if($row->id!="")
		{
			$file_name_1 = "DRD-New-Order.xls";
			$file_name1  = $this->Excel_Model->pendingorder_excel($result,"cronjob_download");
			
			if($file_name1!="")
			{
				$subject = "New Order From D.R. Distributors Pvt. Ltd.";
				$message = "Hello ".ucwords(strtolower($row->uname)). ",<br><br>Please find attached herewith order form for D R Distributors Pvt Ltd in excel format.<br><br>Vipul Gupta <br>Moblie : +919899133989<br>Email : vipul@drdindia.com<br>Address : F2/6 , Okhla Industrial Area Phase 1<br>New Delhi 110020<br><br><b>D.R. Distributors Private Limited.</b>";
				//$message.= $row->uemail;
				
				$subject = base64_encode($subject);
				$message = base64_encode($message);
				
				$user_email_id 	= $row->uemail;
				if($user_email_id=="")
				{
					$user_email_id = "drdwebmail1@gmail.com";
				}
				//$user_email_id 	= "kapil707sharma@gmail.com";
				//$email_other_bcc 	= "kapil7071@gmail.com";
				$email_other_bcc 	= "drdwebmail@gmail.com";
				
				$email_function = "pendingorder";

				$dt = array(
				'user_email_id'=>$user_email_id,
				'subject'=>$subject,
				'message'=>$message,
				'file_name1'=>$file_name1,
				'file_name_1'=>$file_name_1,
				'email_other_bcc'=>$email_other_bcc,
				'email_function'=>$email_function,
				);
				$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
			}
			
			$this->db->query("delete from tbl_pending_order where uemail='$row->uemail'");
		}
	}
	
	public function create_new_staff()
	{
		$result = $this->db->query("select * from tbl_staffdetail")->result();
		foreach($result as $row)
		{
			$row1 = $this->db->query("select * from tbl_staffdetail_other where code='$row->code'")->row();
			if($row1->id=="")
			{
				$code = $row->code;
			}
		}
		echo $code;
		if($code!="")
		{
			header('Content-Type: application/json');
			$json_url = constant('base_url2')."exe01/exe01/create_new_staff/".$code;
			$ch = curl_init($json_url);
			$options = array(
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HTTPHEADER => array('Content-type: application/json'),
			);
			curl_setopt_array($ch,$options);
			$result = curl_exec($ch);
			print_r($result);
		}
	}
	public function delete_old_rec()
	{
		$time = time();
		$day5  = date("Y-m-d", strtotime("-5 days", $time));
		$day2  = date("Y-m-d", strtotime("-5 days", $time));
		$this->db->query("delete FROM `tbl_order` WHERE `date`<'$day5'");
		$this->db->query("delete FROM `tbl_invoice` WHERE `date`<'$day2'");
		
		$result = $this->db->query("select * from tbl_staffdetail_other")->result();
		foreach($result as $row)
		{
			$row1 = $this->db->query("select * from tbl_staffdetail where code='$row->code'")->row();
			if($row1->id=="")
			{
				$code = $row->code;
				$this->db->query("delete from tbl_staffdetail_other where code='$code'");
			}
		}
	}
	
	public function check_order_sahi_insert_hoa_kya_nahi()
	{
		$this->Drd_Invoice_Model->check_order_sahi_insert_hoa_kya_nahi();
	}
	
	public function drd_report_not_pickedby_whatsapp()
	{
		$datetime = date("d-M-Y H:i");
		$res = "";
		$i = 1;
		$result = $this->Drd_Invoice_Model->drd_report_not_pickedby_whatsapp();
		foreach($result as $row)
		{
			$res.= $i.". ".$row->gstvno." | ".$row->altercode." | ".$row->mtime." | Rs.".round($row->amt)."\\n";
			$i++;
		}
		if($res!=""){
			$res = "*Pickedby Report* ($datetime)\\n\\n".$res;
			$group2_message = ($res);
			
			$whatsapp_group2 = "120363040276835738@g.us";
			$this->Message_Model->insert_whatsapp_group_message($whatsapp_group2,$group2_message);
		}
		
		$res = "";
		$i = 1;
		$result = $this->Drd_Invoice_Model->drd_report_not_deliverby_whatsapp();
		foreach($result as $row)
		{
			$res.= $i.". ".$row->gstvno." | ".$row->altercode." | ".$row->mtime." | Rs.".round($row->amt)."\\n";
			$i++;
		}
		if($res!=""){
			$res = "*Deliverby Report* ($datetime)\\n\\n".$res;
			$group2_message = ($res);
			
			$whatsapp_group2 = "120363040276835738@g.us";
			$this->Message_Model->insert_whatsapp_group_message($whatsapp_group2,$group2_message);
		}
	}
	
	public function all_message_send_by()
	{
		$this->Message_Model->send_email_message();
		$this->Message_Model->send_whatsapp_message();
		$this->Message_Model->send_whatsapp_group_message();
		
		$time  = time();
		$th = date('H',$time);
		$ti = date('i',$time);
		
		if($th=="10" && $ti=="01")
		{
			$this->delete_old_rec();
		}
		if($th==11)
		{
			$this->create_new_staff();
		}
		if($th==12)
		{
			$this->check_order_sahi_insert_hoa_kya_nahi();
		}
	}
	
	public function invoice_job1()
	{
		$this->Drd_Invoice_Model->copy_invoice();
		$this->Drd_Invoice_Model->check_delivery();
	    $this->Drd_Invoice_Model->create_invoice_excle();
	}	
	
	public function Corporate_report()
	{
		$from_1 = date('d');
		if($from_1=="01")
		{
			$this->Corporate_monthly_report();
		}
		else
		{
			$this->Corporate_daily_report();
		}
		$this->pendingorder_email();
		$this->corporate_whatsapp_report();
	}
	
	public function Corporate_daily_report()
	{
		$from 	= date('Y-m-01');
		$to 	= date('Y-m-t');
		$dbchange = "0";
		
		$time  = time();
		$from1 	= date('Y-m-d', strtotime("-1 days", $time));
		$to1 	= date('Y-m-d', strtotime("-1 days", $time));
		
		$daily_date = date('Y-m-d');		
		$today_date = date('d-M-Y');
		$daily_date1  = date("Y-m-d", strtotime("+1 days", $time));
		
		$hourly1  = date("H", strtotime("+60 minutes", $time));

		$row = $this->db->query("select tbl_staffdetail.memail,stock_and_sales_analysis_daily_email,item_wise_report_daily_email,chemist_wise_report_daily_email,tbl_staffdetail_other.status,tbl_staffdetail.`compcode`,tbl_staffdetail.`company_full_name`,tbl_staffdetail.`division`,tbl_staffdetail.`id`,tbl_staffdetail_other.`id` as id1,tbl_staffdetail.`code` from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.daily_date='$daily_date' limit 1")->row();		
		if($row->id!="")
		{			
			$user_session  = $row->id;
			$user_division = $row->division;
			$user_compcode = $row->compcode;
			$company_full_name = $row->company_full_name;
			
			$id1  = $row->id1;
			
			
			$file_name1 = $file_name2 = $file_name3 = "";
			$file_name_1 = $file_name_2 = $file_name_3 = "";
			if($row->stock_and_sales_analysis_daily_email=="1")
			{
				$file_name1  = $this->Excel_Model->staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download",$dbchange);
				$file_name_1 = "DRD-Sales-and-stock-report.xls";
			}
			
			if($row->item_wise_report_daily_email=="1")
			{
				$file_name2  = $this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_2 = "DRD-Item-wise-report.xls";
			}
			
			if($row->chemist_wise_report_daily_email=="1")
			{
				$file_name3  = $this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_3 = "DRD-Chemist-wise-report.xls";
			}
			
			if($file_name1!="" || $file_name2!="" || $file_name3!="")
			{
				$subject = "Daily Report (".$today_date.") ".ucwords(strtolower($company_full_name))." (".$user_division.")";
				$message = "Please Find Attachment...<br>";
				//$message.= $row->memail;
				
				$subject = base64_encode($subject);
				$message = base64_encode($message);
				
				$user_email_id 		= $row->memail;
				$email_other_bcc 	= "drdwebmail@gmail.com";
				if($user_email_id=="")
				{
					$user_email_id  = "drdwebmail1@gmail.com";
				}
				//$user_email_id 	= "kapil707sharma@gmail.com";
				
				$email_function = "corporate_report";

				$dt = array(
				'user_email_id'=>$user_email_id,
				'subject'=>$subject,
				'message'=>$message,
				'file_name1'=>$file_name1,
				'file_name_1'=>$file_name_1,
				'file_name2'=>$file_name2,
				'file_name_2'=>$file_name_2,
				'file_name3'=>$file_name3,
				'file_name_3'=>$file_name_3,
				'email_other_bcc'=>$email_other_bcc,
				'email_function'=>$email_function,
				);
				$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
			}
			
			$this->db->query("update tbl_staffdetail_other set daily_date='$daily_date1',hourly='$hourly1' where id='$id1'");
		}
	}
	
	
	public function Corporate_monthly_report()
	{
		$time   = time();
		$hh 	= date("H",$time);
		$date 	= date();
		
		$yy 	= date('Y', strtotime("-1 days", $time));
		$mm 	= date('m', strtotime("-1 days", $time));
		$mm1 	= date('M', strtotime("-1 days", $time));
		$last 	= date('t', strtotime("-1 days", $time));
		$from 	= "$yy-$mm-01";
		$to 	= "$yy-$mm-$last";
		
		/***************************
		$from 	= "2021-08-01";
		$to 	= "2021-08-31";
		/***************************/
		$dbchange = "1";
	
		$from1 	= $from;
		$to1 	= $to;
		
		$monthly_date = date('Y-m-d');		
		$today_date = "01 to $last-$mm1-$yy";
		/***************************
		$today_date = "01 to 31-Aug-2021";
		/***************************/
		$hourly1  = date("H", strtotime("+60 minutes", $time));
		$daily_date1  = date("Y-m-d", strtotime("+1 days", $time));

		$row = $this->db->query("select tbl_staffdetail.memail,stock_and_sales_analysis_daily_email,item_wise_report_monthly_email,chemist_wise_report_monthly_email,tbl_staffdetail_other.status,tbl_staffdetail.`compcode`,tbl_staffdetail.`company_full_name`,tbl_staffdetail.`division`,tbl_staffdetail.`id`,tbl_staffdetail_other.`id` as id1,tbl_staffdetail.`code` from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.daily_date='$monthly_date' limit 1")->row();		
		if($row->id!="")
		{			
			$user_session  = $row->id;
			$user_division = $row->division;
			$user_compcode = $row->compcode;
			$company_full_name = $row->company_full_name;
			
			$id1  = $row->id1;
			
			$file_name1 = $file_name2 = $file_name3 = "";
			$file_name_1 = $file_name_2 = $file_name_3 = "";
			if($row->stock_and_sales_analysis_daily_email=="1")
			{
				/*$file_name1  = $this->Excel_Model->staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download",$dbchange);
				$file_name_1 = "DRD-Sales-and-stock-report.xls";*/
			}
			
			if($row->item_wise_report_monthly_email=="1")
			{
				$file_name2  = $this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_2 = "DRD-Item-wise-report.xls";
			}
			
			if($row->chemist_wise_report_monthly_email=="1")
			{
				$file_name3  = $this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_3 = "DRD-Chemist-wise-report.xls";
			}
			
			if($file_name1!="" || $file_name2!="" || $file_name3!="")
			{
				$subject = "Monthly Report (".$today_date.") ".ucwords(strtolower($company_full_name))." (".$user_division.")";
				$message = "Please Find Attachment...<br>";
				//$message.= $row->memail;
				
				$subject = base64_encode($subject);
				$message = base64_encode($message);
				
				$user_email_id 	   = $row->memail;
				$email_other_bcc   = "drdwebmail@gmail.com";
				if($user_email_id=="")
				{
					$user_email_id = "drdwebmail1@gmail.com";
				}
				//$user_email_id 	= "kapil707sharma@gmail.com";
				
				$email_function = "corporate_report";

				$dt = array(
				'user_email_id'=>$user_email_id,
				'subject'=>$subject,
				'message'=>$message,
				'file_name1'=>$file_name1,
				'file_name_1'=>$file_name_1,
				'file_name2'=>$file_name2,
				'file_name_2'=>$file_name_2,
				'file_name3'=>$file_name3,
				'file_name_3'=>$file_name_3,
				'email_other_bcc'=>$email_other_bcc,
				'email_function'=>$email_function,
				);
				$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
			}
			
			$this->db->query("update tbl_staffdetail_other set daily_date='$daily_date1',hourly='$hourly1' where id='$id1'");
		}
	}
	
	public function corporate_whatsapp_report()
	{
		$time  	 	= time();
		$today_time = date("H:i",$time);
		
		$hourly   = date("H",$time);
		$hourly1  = date("H", strtotime("+60 minutes", $time));
		
		$today_date = date('Y-m-d');
		
		$result = $this->db->query("select tbl_staffdetail_other.whatsapp_message,tbl_staffdetail.staffname,tbl_staffdetail.mobilenumber,tbl_staffdetail_other.status,tbl_staffdetail.`compcode`,tbl_staffdetail.`company_full_name`,tbl_staffdetail.`division`,tbl_staffdetail.`id`,tbl_staffdetail_other.`id` as id1,tbl_staffdetail.`code` from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.hourly='$hourly' and tbl_staffdetail_other.whatsapp_message='1' limit 10")->result();
		foreach($result as $row)
		{
			$staffname= ucwords(strtolower($row->staffname));
			$compcode = $row->compcode;
			$division = $row->division;
			
			$mobile  		= "+91".$row->mobilenumber;
			$user_session  	= $row->id;
			$user_division 	= $row->division;
			$user_compcode 	= $row->compcode;
			$company_full_name = $row->company_full_name;
			
			$id1  = $row->id1;
			
			$result1 = $this->Corporate_Model->corporate_sales_report($compcode,$division,$today_date);
			$corporate_sales_report = "";
			$i =  1 ;
			$med_name = "";
			foreach($result1 as $row1)
			{
				if($med_name!=$row1->name)
				{
					$i =  1;
					$med_name=$row1->name;
					$corporate_sales_report.= "*".ucwords(strtolower($row1->name))."* Stock (".round($row1->clqty)."),Total Sales (".round($row1->total_sales).")\\n";
				}
				$corporate_sales_report.= $i++.". ".$row1->a_name." (".$row1->altercode.") (Sales : ".round($row1->qty).") \\nAddress :- $row1->address \\nMobile :- $row1->mobile \\n\\n";
			}
			
			$subject = "Hourly Sales Report (".$today_time.")";
			$whatsapp_message = "Hello $staffname\\n*".ucwords(strtolower($company_full_name))." (".$user_division.")*<br> ------------------------------------------------------ \\n$subject\\n ------------------------------------------------------ \\n$corporate_sales_report";
					
			//$mobile = "+919530005050";
			if($mobile == "+91")
			{
				$mobile = "+919782664507";
			}
			
			if($corporate_sales_report!="")
			{
				$altercode = "";
				$whatsapp_message = base64_encode($whatsapp_message);
				$this->db->query("insert into tbl_whatsapp_message (mobile,message,chemist_id) values ('$mobile','$whatsapp_message','$altercode')");
				
				$mobile = "+919530005050";
				$this->db->query("insert into tbl_whatsapp_message (mobile,message,chemist_id) values ('$mobile','$whatsapp_message','$altercode')");
			}
		
			$this->db->query("update tbl_staffdetail_other set hourly='$hourly1' where id='$id1'");
		}
	}
}