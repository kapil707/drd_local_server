<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit','512M'); // This also needs to be increased in some cases. Can be changed to a higher value as per need)
ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288'); // Setting to 512M - for pdo_sqlsrv
class Drd_Pendingorder_Model extends CI_Model  
{
	var $mssql;
    function __construct()
    {
        parent::__construct();
        $this->mssql = $this->load->database ( 'my_mssql', TRUE );
    }

    public function test_ck(){
       //use $this->mssql instead of $this->db
       $query = $this->mssql->query('select * from acm')->row();
	   return $query;
       //...
    }

    function get_some_mysql_rows(){
       //use  $this->db for default 
       $query = $this->db->query('select * from mysql_table');
       //...
    }
	
	public function view_order_query(){
		return $this->db->query("select distinct barcode,max(qty) as qty,type,ordno,name,vdt,uid,uname,id from tbl_pending_order group by barcode order by acno")->result();
	}
	
	public function copy_shortage_order($start_date='',$end_date=''){
		
		$result = $this->mssql->query("select shortage.uid,shortage.vdt,shortage.itemc,item.barcode,item.name,item.pack,item.division,item.compcode,cmp.name as company_full_name,(select top 1 acno from complist,acm where compcode = item.compcode and complist.acno = acm.code and email!='') as acno,(select top 1 name from acm where code = (select top 1 acno from complist,acm where compcode = item.compcode and complist.acno = acm.code and email!='')) as uname,(select top 1 email from acm where code = (select top 1 acno from complist,acm where compcode = item.compcode and complist.acno = acm.code and email!='')) as uemail,(select top 1 mobile from acm where code = (select top 1 acno from complist,acm where compcode = item.compcode and complist.acno = acm.code and email!='')) as umobile from shortage inner join item on item.code = shortage.itemc inner join company as cmp on cmp.code = item.compcode where shortage.vdt>='$start_date' and shortage.vdt<='$end_date'")->result();
		foreach($result as $row)
		{
			$uid = $row->uid;
			$vdt = $row->vdt;
			$itemc = $row->itemc;
			$barcode = $row->barcode;
			$name = trim($row->name);
			$division = $row->division;
			$compcode = $row->compcode;
			$company_full_name = trim($row->company_full_name);
			$acno = $row->acno;
			$uname = trim($row->uname);
			$uemail = $row->uemail;
			$umobile = $row->umobile;
			$qty = "10";
			$ordno = "0";
			$date = date("Y-m-d");
			$type = "shortage";
			
			$insert_query = "insert into tbl_pending_order (uid,vdt,itemc,barcode,name,pack,division,compcode,company_full_name,acno,uname,uemail,umobile,qty,ordno,date,type) values ('$uid','$vdt','$itemc','$barcode','$name','$pack','$division','$compcode','$company_full_name','$acno','$uname','$uemail','$umobile','$qty','$ordno','$date','$type')";
			
			$this->db->query($insert_query);
			
		}
	}
	
	public function synchronization_fun(){
		
		$result = $this->db->query("select * from tbl_pending_order")->result();
		foreach($result as $row)
		{
			$_id = $row->id;
			$name = $row->name;
			if (substr($name,0,1)==".")
			{
				$insert_query = "delete from tbl_pending_order where id=$_id";
			
				$this->db->query($insert_query);
			}
		}
	}
	
	public function copy_pending_order($order_no='',$start_date='',$end_date=''){
	}
}  