<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Email_Model extends CI_Model
{
	public function tbl_whatsapp_email_fail($number,$message,$altercode)
	{
		$row = $this->db->query("select * from tbl_whatsapp_email_fail where altercode='$altercode'")->row();
		if($row->id=="")
		{
			$this->db->query("insert into tbl_whatsapp_email_fail set altercode='$altercode',mobile='$number',message='$message'");
		}
	}
	function send_email_for_password_create($name,$user_email_id,$altercode,$password)
	{
		$android_url = base_url()."android/".$altercode;
		
		$subject   = "Login Details From D.R. Distributors Pvt. Ltd.";
		$message = "Hello $name,<br><br>Your Login Details for our online ordering system and android application are as below.";
		$message .="<br><br>Username : $altercode <br>Password : $password";
		$message .="<br><br>Please download our new app from Google play store to order medicine <br><br><a href='$android_url'><img src='https://www.getmigo.com/coverage/us/tennessee/memphis/static/play-store-1cacd18258fc9c52bc3442564740d218.png' width='150px' height='50px'/></a>";
		
		if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
		}
		else{
			$err = $user_email_id." is Wrong Email";
			$mobile = "";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			$user_email_id="";
		}
		if($user_email_id!="")
		{
			$subject = base64_encode($subject);
			$message = base64_encode($message);
			$email_function = "password";
			$mail_server = "gmail";

			$dt = array(
			'user_email_id'=>$user_email_id,
			'subject'=>$subject,
			'message'=>$message,
			'email_function'=>$email_function,
			'mail_server'=>$mail_server,
			);
			$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		}
	}	
	public function save_order($temp_rec,$order_id)
	{
		error_reporting(0);
		$query = $this->db->query("select * from tbl_order where temp_rec='$temp_rec' and order_id='$order_id' ")->result();
		$total_rs = $count_line = 0;
		foreach($query as $row1)
		{
			$user_type 	= $row1->user_type;
			$chemist_id = $row1->chemist_id;
			$selesman_id= $row1->selesman_id;
			$total_rs 	= ($row1->sale_rate * $row1->quantity) + $total_rs;
			$count_line++;
		}
		$total_rs = round($total_rs,2);
		if($user_type=="chemist")
		{
			$users = $this->db->query("select * from tbl_acm where altercode='$chemist_id' ")->row();
			$acm_altercode 	= $users->altercode;
			$acm_name		= ucwords(strtolower($users->name));
			$acm_email 		= $users->email;
			$acm_mobile 	= $users->mobile;			
			
			$chemist_excle 	= "$acm_name ($acm_altercode)";
			$file_name 		= $acm_altercode;
		}
		if($user_type=="sales")
		{
			//jab sale man say login hota ha to
			$users = $this->db->query("select * from tbl_acm where altercode='$chemist_id' ")->row();
			$user_session	= $users->id;
			$acm_altercode 	= $users->altercode;
			$acm_name 		= ucwords(strtolower($users->name));
			$acm_email 		= $users->email;
			$acm_mobile 	= $users->mobile;

			$users = $this->db->query("select * from tbl_users where customer_code='$selesman_id' ")->row();
			$salesman_name 		= $users->firstname." ".$users->lastname;
			$salesman_mobile	= $users->cust_mobile;
			$salesman_altercode	= $users->customer_code;
			
			$chemist_excle 	= $acm_name." ($acm_altercode)";
			$file_name 		= $acm_altercode;
		}
		
		$android_url = base_url()."android/".$acm_altercode;
		/*****************whtsapp message*****************************/	
		if($user_type == "sales")
		{
			if($salesman_mobile!="")
			{
				$w_number 		= "+91".$salesman_mobile;//$c_cust_mobile;
				$w_altercode 	= $acm_altercode;
				$w_message 		= "New Order Placed - $order_id for $acm_name for amount $total_rs";
				$this->Email_Model->whatsapp_message($w_number,$w_message,$w_altercode);
				
				/*$w_title = "New Order Placed - $order_id";				$this->Email_Model->send_android_notification("4",$w_title,$w_message,$w_altercode,"chemist");*/
			}
		}
		
		if($acm_mobile != "")
		{
			$w_number 		= "+91".$acm_mobile;//$c_cust_mobile;
			$w_altercode 	= $acm_altercode;
			$w_message 		= "Hi $acm_name,\\n \\nYour Order with reference number $order_id is placed successfully online for ($count_line) medicines for approx value of $total_rs. - Thanks D. R. Distributors Private Limited";
			$this->Email_Model->whatsapp_message($w_number,$w_message,$w_altercode);
			
			/*************27-11-19***********************/
			$q_altercode 	= $acm_altercode;
			$q_title 	= "New Order - $order_id";
			$q_message	= "Hi $acm_name <br>Your Order with reference number $order_id is placed successfully online for ($count_line) medicines for approx value of $total_rs. - Thanks <b>D. R. Distributors Private Limited</b>";
			$this->Email_Model->send_android_notification("4",$q_title,$q_message,$q_altercode,"chemist");
			/************************************************/
		}
		else
		{
			$err = "Number not Available";
			$mobile = "";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$acm_altercode);
		}
		/******************group message******************************/
		$w_message 	= "New Order Recieved from $acm_name with order ID - $order_id for value of $total_rs . Please check in Easy Sol";
		$whatsapp_group1 = $this->Scheme_Model->get_website_data("whatsapp_group1");
		//$w_group 	= "919899333989-1567708298@g.us";
		$this->Email_Model->whatsapp_group_message($whatsapp_group1,$w_message,$w_altercode);
		/**********************************************************/
		
		$subject = "DRD | New Order | $order_id | $acm_name";
		$message = "Hi $acm_name,<br> You have placed a new order using DRD App <br><br>";
		$message.= "Order ID: $order_id <br>";	

		if($user_type == "sales"){
			$message.="Salesman : ".$salesman_name." (".$salesman_altercode.")<br>";
			$message.="Chemist : ".$acm_name." (".$acm_altercode.")";
		}
		if($user_type == "chemist"){
			$message.="Chemist : ".$acm_name." (".$acm_altercode.")";
		}

		$message.="<br>Total Rs. $total_rs";
		$message .="<br><br>Please download our new app from Google play store to order medicine <br><br><a href='$android_url'><img src='https://www.getmigo.com/coverage/us/tennessee/memphis/static/play-store-1cacd18258fc9c52bc3442564740d218.png' width='150px' height='50px'/></a>";
		$message.= $email_footer;

		$user_email_id = $acm_email;
		if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {

		}
		else{
			
			$err = $user_email_id." is Wrong Email";
			$mobile = "";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$acm_altercode);
			
			$user_email_id="";			
		}

		if($user_email_id!="")
		{
			$file_name_1 = "DRD-Order.xls";
			$file_name1 = $this->Excel_Model->save_order($temp_rec,$order_id,$chemist_excle);
			
			$subject = base64_encode($subject);
			$message = base64_encode($message);
			$email_function = "save_order";
			$mail_server = "drdorder";

			$dt = array(
			'user_email_id'=>$user_email_id,
			'subject'=>$subject,
			'message'=>$message,
			'email_function'=>$email_function,
			'file_name1'=>$file_name1,
			'file_name_1'=>$file_name_1,
			'mail_server'=>$mail_server,
			);
			$this->Scheme_Model->insert_fun("tbl_email_send",$dt);				
		}		
	}
	
	public function whatsapp_message($mobile,$message,$altercode)
	{
		$time = time();
		$date = date("Y-m-d",$time);

		$dt = array(
		'mobile'=>$mobile,
		'message'=>base64_encode($message),
		'chemist_id'=>$altercode,
		'time'=>$time,
		'date'=>$date,
		);
		$this->Scheme_Model->insert_fun("tbl_whatsapp_message",$dt);
	}
	
	public function send_whatsapp_message($mobile,$message,$media,$altercode)
	{		
		$whatsapp_key = $this->Scheme_Model->get_website_data("whatsapp_key");
		
		if($media!="")
		{
			$parmiter = '{"phone": "'.$mobile.'","message": "'.$message.'","media": { "file": "'.$media.'" }}';
		}
		if($media=="")
		{
			$parmiter = "{\"phone\":\"$mobile\",\"message\":\"$message\"}";
		}

		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://api.wassi.chat/v1/messages",
		CURLOPT_RETURNTRANSFER=>true,
		CURLOPT_ENCODING =>"",
		CURLOPT_MAXREDIRS =>10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION =>CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS =>$parmiter,
		CURLOPT_HTTPHEADER =>array("content-type: application/json","token:$whatsapp_key"),));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
			echo "cURL Error #:" . $err;
			$err = "Number stored is : $mobile";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
		} else {
			echo $response;
			$someArray = json_decode($response,true);
			if($someArray["status"]=="400"||$someArray["status"]=="401"||$someArray["status"]=="409"||$someArray["status"]=="500"||$someArray["status"]=="501"||$someArray["status"]=="503")
			{
				$err = "Number stored is : $mobile";
				$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			}
		}
	}
	
	public function whatsapp_group_message($number,$message,$altercode)
	{
		$whatsapp_key = $this->Scheme_Model->get_website_data("whatsapp_key");
		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://api.wassi.chat/v1/messages",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => "{\"group\":\"$number\",\"priority\":\"high\",\"message\":\"$message\"}",
		CURLOPT_HTTPHEADER => array(
		"content-type: application/json","token:$whatsapp_key"),));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
			echo "cURL Error #:" . $err;
			//$this->Email_Model->tbl_whatsapp_email_fail($number,$err,$altercode);
		} else {
			//echo $response;
			$someArray = json_decode($response,true);
			if($someArray["status"]=="400"||$someArray["status"]=="401"||$someArray["status"]=="409"||$someArray["status"]=="500"||$someArray["status"]=="501"||$someArray["status"]=="503")
			{
				//$this->Email_Model->tbl_whatsapp_email_fail($number,$response,$altercode);
			}
		}
	}
	
	public function order_send_type1($gstvno,$acno,$vdt)
	{	
		$dt = "<table border='1' width='100%'><tr><td>ITEM NAME</td><td>QTY</td><td>BATCH</td><td>EXPIRY</td></tr>";
		$q = $this->db->query("select item_name,qty,batch,expiry from tbl_sales where gstvno='$gstvno' and vdt='$vdt' and mdatatype='insert'")->result();
		foreach($q as $row)
		{
			$dt.= "<tr><td>".$row->item_name."</td><td>".round($row->qty)."</td><td>".$row->batch."</td><td>".$row->expiry."</td></tr>";
		}
		$dt.= "</table>";	
		return $dt;
	}

	public function order_send_type2($gstvno,$acno,$vdt)
	{
		$q = $this->db->query("select delete_descp,item_name,delete_amt,delete_namt from tbl_sales where gstvno='$gstvno' and vdt='$vdt' and mdatatype='delete'")->result();
		foreach($q as $row)
		{
			//$row->delete_descp=="BATCH CHANGE"
			if($row->delete_descp=="QTY.CHANGE" || $row->delete_descp=="ITEM DELETE")
			{
				$dt1 = "<br><br>Following Items have changed from the orignal order. <br><br><table border='1' width='100%'><tr><td>ITEM NAME</td><td>Ordered</td><td>Billed</td><td></td></tr>";

				$dt.= "<tr><td>".$row->item_name."</td><td>".$row->delete_amt."</td><td>".$row->delete_namt."</td><td>".$row->delete_descp."</td></tr>";
				$dt2.= "</table>";
			}
		}
		return $dt1.$dt.$dt2;
	}

	public function order_send_type3($gstvno,$acno,$vdt)
	{
		$myi = 1;
		$dt1 = "\\n \\nAll items in your order have been billed *without any shortage*.";
		$dt1 = "<br>All items in your order have been billed <b>without any shortage</b>.";
		$q = $this->db->query("select delete_descp,item_name,delete_amt from tbl_sales_deleted where gstvno='$gstvno' and vdt='$vdt'")->result();
		foreach($q as $row)		{

			//$row->delete_descp=="QTY.CHANGE" || $row->delete_descp=="BATCH CHANGE"
			if($row->delete_descp=="ITEM DELETE")
			{
				$dt1 = "\\n \\nFollowing items have been *deleted* from your order: \\n";
				$dt.= "\\n*$myi*. *".$row->item_name."*\\n   *Quantity : ".$row->delete_amt."*";
				
				
				$dt2 = "<br>Following items have been *deleted* from your order: <br>";
				$dt_.= "<br><b>$myi</b>. <b>".$row->item_name."</b><br>   <b>Quantity : ".$row->delete_amt."</b>";
				$myi++;
			}
		}
		$x[0] = $dt1.$dt;
		$x[1] = $dt2.$dt_;		
		return $x;
	}
	
	function import_orders_delete_items($message,$altercode,$user_email_id,$date,$time)
	{	
		$android_url = base_url()."android/".$altercode;		
		$subject   = "Delete Items From D.R. Distributors Pvt. Ltd.";
		
		$message .="<br><br>Please download our new app from Google play store to order medicine <br><br><a href='$android_url'><img src='https://www.getmigo.com/coverage/us/tennessee/memphis/static/play-store-1cacd18258fc9c52bc3442564740d218.png' width='150px' height='50px'/></a>";

		if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
		}
		else{
			$err = $user_email_id." is Wrong Email";
			$mobile = "";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			
			$user_email_id="";
		}
		
		if($user_email_id!="")
		{
			$file_name_1 = "Deleted-Items-Report.xls";
			$file_name1  = $this->Excel_Model->import_orders_delete_items($date,$time);
			
			$subject = base64_encode($subject);
			$message = base64_encode($message);
			$email_function = "import_orders_delete_items";
			$mail_server = "gmail";
			
			$dt = array(
			'user_email_id'=>$user_email_id,
			'subject'=>$subject,
			'message'=>$message,
			'email_function'=>$email_function,
			'file_name1'=>$file_name1,
			'file_name_1'=>$file_name_1,
			'mail_server'=>$mail_server,
			);
			$this->Scheme_Model->insert_fun("tbl_email_send",$dt);				
		}
	}
	
	/******************29-01-2020*******************************/
	
	public function sales_deleted_daily_report($vdt)
	{
		error_reporting(0);		
		
		$vt 		= date("d-M-y", strtotime($vdt));		
		$myx_array 	= $this->Excel_Model->sales_deleted_daily_report($vdt);
		$subject   	= "Sales Deleted Daily Report $vt From D.R. Distributors Pvt. Ltd.";
		$message 	= "Sales Deleted Daily Report Total Items is ".$myx_array[2]." Total Price Is ".$myx_array[3];
		
		$file_name_1 = "Sales_deleted_daily_report_".$vdt.".xls";
		$file_name1  = $myx_array[0];
		
		$file_name_2 = "Sales_deleted_daily_report_chemist_wise_".$vdt.".xls";
		$file_name2  = $this->Excel_Model->sales_deleted_daily_report_chemist_wise($vdt);
				
		$subject = base64_encode($subject);
		$message = base64_encode($message);
		$email_function = "sales_deleted_daily_report";
		$mail_server = "gmail";
		
		$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
		$user_email_id = $row->email;

		$dt = array(
		'user_email_id'=>$user_email_id,
		'subject'=>$subject,
		'message'=>$message,
		'email_function'=>$email_function,
		'file_name1'=>$file_name1,
		'file_name2'=>$file_name2,
		'file_name_1'=>$file_name_1,
		'file_name_2'=>$file_name_2,
		'mail_server'=>$mail_server,
		);
		$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		
		$this->db->query("update tbl_sales_deleted set email_status='1' where vdt='$vdt' and email_status='0'");			
	}

	/******************27-11-19*****update 22-04-2020****************/
	public function send_android_notification($funtype,$title,$message,$chemist_id,$user_type)
	{
		$time = time();
		$date = date("Y-m-d",$time);
		
		$title 		= base64_encode($title);
		$message 	= base64_encode($message);
		
		/*$result = $this->db->query("select * from tbl_android_device_id where chemist_id='$chemist_id'")->result();
		foreach($result as $row)
		{
			$device_id =  $row->device_id;
			
			$dt = array(
			'chemist_id'=>$chemist_id,
			'user_type'=>$user_type,
			'title'=>$title,
			'funtype'=>$funtype,
			'message'=>$message,
			'time'=>$time,
			'date'=>$date,
			'device_id'=>$device_id,);
			
			$this->Scheme_Model->insert_fun("tbl_new_notification",$dt);
		}*/
		
		$device_id =  "default"; // yha sirf website or android me show ke liya use hota ha web page par show ki liya sirf
			
		$dt = array(
		'chemist_id'=>$chemist_id,
		'user_type'=>$user_type,
		'title'=>$title,
		'funtype'=>$funtype,
		'message'=>$message,
		'time'=>$time,
		'date'=>$date,
		'device_id'=>$device_id,);
		
		$this->Scheme_Model->insert_fun("tbl_new_notification",$dt);
	}
	
	/******************07-12-19********************************/
	
	public function insert_pending_order_fail_report($date_range)
	{
		error_reporting(0);
		$file_name_1 = "Fail-order.xls";
		$file_name1	 = $this->Excel_Model->insert_pending_order_fail_report($date_range);
		$mail_server = "gmail";
			
		$subject = "New Order || D R Distributors Private Limited.";
		$message = "Hi Vipul,<br><br>Please supply the order in the attachment<br><br>Thanks<br><br>D R Distributors Private Limited.";
		
		$subject = base64_encode($subject);
		$message = base64_encode($message);
		$email_function = "pending_order";
		
		$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
		$user_email_id = $row->email;

		$dt = array(
		'user_email_id'=>$user_email_id,
		'subject'=>$subject,
		'message'=>$message,
		'email_function'=>$email_function,
		'file_name1'=>$file_name1,
		'file_name_1'=>$file_name_1,
		'mail_server'=>$mail_server,
		);
		$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		$this->db->query("delete from tbl_pending_order where status='2'");
	}
	
	//03-01-2020
	public function new_insert_pending_order($user_email_id,$company,$date_range,$staff_compcode)
	{
		error_reporting(0);		
		$tbl_staffdetail = $this->db->query("select memail from tbl_staffdetail where compcode='$staff_compcode'")->result();
		foreach($tbl_staffdetail as $tbl_staffdetail_ok)
		{
			$email_other_bcc.= $tbl_staffdetail_ok->memail.",";
		}
		$email_other_bcc = rtrim($email_other_bcc, ',');
		
		$file_name_1 = "New-Order.xls";
		$file_name1	 = $this->Excel_Model->insert_pending_order($company,$date_range);
		$mail_server = "gmail";
			
		$subject = "Order || D R Distributors Private Limited.";
		$message = "Sir,<br><br>Please supply the order in the attachment<br><br>Thanks<br><br>Vipul<br><br>D R Distributors Private Limited.";
		
		$subject = base64_encode($subject);
		$message = base64_encode($message);
		$email_function = "pending_order";

		$dt = array(
		'user_email_id'=>$user_email_id,
		'subject'=>$subject,
		'message'=>$message,
		'email_function'=>$email_function,
		'file_name1'=>$file_name1,
		'file_name_1'=>$file_name_1,
		'mail_server'=>$mail_server,
		'email_other_bcc'=>$email_other_bcc,
		);
		$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		$this->db->query("delete from tbl_pending_order where company='$company'");
	}
	
	/*****************24-01-2020***********************/
	public function new_email_send($user_email_id,$subject,$message,$email_function,$file_name1,$file_name2,$file_name3,$file_name_1,$file_name_2,$file_name_3,$email_other_bcc,$mail_server)
	{
		error_reporting(0);
		
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		if($mail_server=="")
		{
			$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
			
			$addreplyto 		= $row->addreplyto;
			$addreplyto_name 	= $row->addreplyto_name;
			$server_email 		= $row->server_email;
			$server_email_name 	= $row->server_email_name;
			$email1 			= $row->email;
			$email_bcc 			= $row->email_bcc;
			$live_or_demo 		= $row->live_or_demo;
			
			$email->AddReplyTo($addreplyto,$addreplyto_name);
			$email->SetFrom($server_email,$server_email_name);
			
			$email->Subject   	= $subject;
			$email->Body 		= $message;		
			if($live_or_demo=="Demo")
			{
				$email->AddAddress($email1);
				$email_bcc = explode (",", $email_bcc);
				foreach($email_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}
			else
			{
				$email->AddAddress($user_email_id);
				$email->addBcc($email1);
				$email_bcc = explode (",", $email_bcc);
				foreach($email_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
				$email_other_bcc = explode (",", $email_other_bcc); 				
				foreach($email_other_bcc as $email_other_bcc_ok)
				{
					$email->addBcc($email_other_bcc_ok->memail);
				}
			}
			if($file_name1)
			{
				if($file_name_1)
				{
					$email->addAttachment($file_name1,$file_name_1);
				}
				else
				{
					$email->addAttachment($file_name1);
				}
			}
			if($file_name2)
			{
				if($file_name_2)
				{
					$email->addAttachment($file_name2,$file_name_2);
				}
				else
				{
					$email->addAttachment($file_name2);
				}
			}
			if($file_name3)
			{
				if($file_name_3)
				{
					$email->addAttachment($file_name3,$file_name_3);
				}
				else
				{
					$email->addAttachment($file_name3);
				}
			}
			
			$email->IsHTML(true);		
			if($email->Send()){
				echo "Mail Sent";
			}
			else{
				echo "Mail Failed";
			}
			if($file_name1)
			{
				unlink($file_name1);
			}
			if($file_name2)
			{
				unlink($file_name2);
			}
			if($file_name3)
			{
				unlink($file_name3);
			}
		}
		/************************28-01-2020**************************/
		if($mail_server=="gmail" || $mail_server=="drdinvoice" || $mail_server=="drdorder")
		{
			$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
			
			$email->CharSet 	= 'UTF-8';
			
			$addreplyto 		= $row->addreplyto;
			$addreplyto_name 	= $row->addreplyto_name;
			$server_email 		= $row->server_email;
			$server_email_name 	= $row->server_email_name;
			$email1 			= $row->email;
			$email_bcc 			= $row->email_bcc;
			$live_or_demo 		= $row->live_or_demo;
			
			//$email->AddReplyTo($addreplyto,$addreplyto_name);
			$email->SetFrom($server_email,$server_email_name);
			
			$count = 0;
			$email->Subject   	= $subject;
			$email->Body 		= $message;		
			if($live_or_demo=="Demo")
			{
				$email->AddAddress($email1);
				$count++;
				$email_bcc = explode (",", $email_bcc);
				foreach($email_bcc as $bcc)
				{
					$email->addBcc($bcc);
					$count++;
				}
			}
			else
			{
				$email->AddAddress($user_email_id);
				$count++;
				$email->addBcc($email1);
				$count++;
				if($email_bcc!="")
				{
					$email_bcc = explode (",", $email_bcc);
					foreach($email_bcc as $bcc)
					{
						$email->addBcc($bcc);
						$count++;
					}
				}
				if($email_other_bcc!="")
				{
					$email_other_bcc = explode (",", $email_other_bcc); 				
					foreach($email_other_bcc as $email_other_bcc_ok)
					{
						$email->addBcc($email_other_bcc_ok->memail);
						$count++;
					}
				}
			}
			if($file_name1)
			{
				if($file_name_1)
				{
					$email->addAttachment($file_name1,$file_name_1);
				}
				else
				{
					$email->addAttachment($file_name1);
				}
			}
			if($file_name2)
			{
				if($file_name_2)
				{
					$email->addAttachment($file_name2,$file_name_2);
				}
				else
				{
					$email->addAttachment($file_name2);
				}
			}
			if($file_name3)
			{
				if($file_name_3)
				{
					$email->addAttachment($file_name3,$file_name_3);
				}
				else
				{
					$email->addAttachment($file_name3);
				}
			}
			
			$email->IsHTML(true);
			
			if($mail_server=="drdinvoice" || $mail_server=="drdorder")
			{
				$mail_server = $this->get_email_send_email_id($count,$mail_server);
			}
			
			$row1 = $this->db->query("select * from tbl_gmail_username_password where mail_server='$mail_server' order by id desc")->row();
			$email->IsSMTP();
			$email->SMTPAuth   = true; 
			$email->SMTPSecure = "ssl";  //tls
			$email->Host       = "smtp.googlemail.com";
			$email->Port       = 465; //you could use port 25, 587, 465 for googlemail
			$email->Username   = $row1->email;
			$email->Password   = $row1->password;
			
			if($email->Send()){
				echo "Mail Sent";
			}
			else{
				echo "Mail Failed";
			}
			
			if($file_name1)
			{
				unlink($file_name1);
			}
			if($file_name2)
			{
				unlink($file_name2);
			}
			if($file_name3)
			{
				unlink($file_name3);
			}
		}
		
	}
	
	/******************28-01-2020*************************/	
	public function chemist_invoice_report($gstvno,$acno,$vdt,$time,$url_link)
	{
		//error_reporting(0);
		$this->db->query("update tbl_sales_main set email_status='1' where gstvno='$gstvno' and acno='$acno' and vdt='$vdt'");
		$date_time = date("d-M-y",strtotime($vdt));

		/******************************************************/
		$order_send_type1 	= $this->order_send_type1($gstvno,$acno,$vdt);
		$order_send_type2 	= $this->order_send_type2($gstvno,$acno,$vdt);
		$order_send_type_x 	= $this->order_send_type3($gstvno,$acno,$vdt);
		$order_send_type3 	= $order_send_type_x[0];
		$order_send_type3_1 = $order_send_type_x[1];
		$vdt1 = date("d-M-Y",strtotime($vdt));	

		$q = $this->db->query("select * from tbl_acm where code='$acno'")->row();
		$user_email_id	= $q->email;
		$name 			= ucwords(strtolower($q->name));
		$file_name 		= $q->name;
		$invexport 		= $q->invexport;
		$q_mobile 		= $q->mobile;
		$q_altercode	= $q->altercode;
		$chemist_id		= $q->altercode;

		$link 			= base_url()."invoice/".$url_link;
		$link2 			= base_url()."invoice/".$url_link;
		$android_url 	= base_url()."android/".$q_altercode;
		$noti_url 		= base_url()."android/".$q_altercode;		

		$whatsapp_number = $this->Scheme_Model->get_website_data("whatsapp_number");
		$whatsapp_live_or_demo = $this->Scheme_Model->get_website_data("whatsapp_live_or_demo");
		if($whatsapp_live_or_demo=="Demo" || $whatsapp_live_or_demo=="demo")
		{
			$q_mobile = $whatsapp_number;
			$staff_mobile = $whatsapp_number;
		}
		else
		{
			if($q_mobile=="")
			{
				$err = "Number not Available";
				$mobile = "";
				$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$q_altercode);
			}
			else
			{
				$q_mobile = "+91".$q_mobile;
			}
		}
		
		$whatsapp_footer = $this->Scheme_Model->get_website_data("whatsapp_footer");
		if($q_mobile!="")
		{
			$q_message = "Hi $name ($q_altercode), \\n \\nInvoice *$gstvno* for Order dated $date_time has been generated by *D R Distributors Private Limited*. $order_send_type3 \\n \\nYou can check your invoice by clicking on $link \\n \\nOn laptop or pc you can visit following link to start placing orders http://drdistributor.com/chemist \\n \\nPlease download our app from Google play store : $android_url \\n \\n$whatsapp_footer";
			$this->Email_Model->whatsapp_message($q_mobile,$q_message,$q_altercode);
			
			$q_title = "Invoice $gstvno Generated";
			// off 30-06-2020//$q_message = "Hi $name ($q_altercode),<br>Invoice <b>$gstvno</b> for Order dated $date_time has been generated by <b>D R Distributors Private Limited</b>. $order_send_type3_1 <br>You can check your invoice by clicking on <a href='$link2'>$link2</a><br>";
			$q_message = "Hi $name ($q_altercode),<br>Invoice <b>$gstvno</b> for Order dated $date_time has been generated by <b>D R Distributors Private Limited</b>. $order_send_type3_1";
			$this->Email_Model->send_android_notification("5",$q_title,$q_message,$q_altercode,"chemist");
			//$this->auth_model->send_sms_fun($q_mobile,$msg);
		}
		
		if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
		}
		else{
			$err = $user_email_id." is Wrong Email";
			$mobile = "";
			$this->Email_Model->tbl_whatsapp_email_fail($mobile,$err,$q_altercode);
			
			$user_email_id="";
		}
		
		if($user_email_id!="")
		{
			$subject = "Invoice No. $gstvno From D.R. Distributors Pvt. Ltd.";
			$message = "Hi $name ($chemist_id),<br><br> The order placed by you on $date_time has been processed and an invoice has been generated for the same. Please find the  attatchment with this email.<br><br>";
			$message .= "Please find the list of Items processed<br><br>".$order_send_type1;

			$message .= $order_send_type2."<br><br><a href='".$link."'>Click To Open Invoice</a>";
			$message .= "<br><br>Please download our new app from Google play store to order medicine <br><br><a href='$android_url'><img src='https://www.getmigo.com/coverage/us/tennessee/memphis/static/play-store-1cacd18258fc9c52bc3442564740d218.png' width='150px' height='50px'/></a>";

			$file_name_1= substr($file_name,0,19);
			$file_name_1= $gstvno."_D.R.DISTRIBUTORS PVT_".$file_name_1.".txt";
			$file_name_2= $gstvno."_D.R.DISTRIBUTORS PVT_".$file_name_1.".xls";
						
			$file_name1 = $this->Excel_Model->chemist_invoice_report_txt($gstvno,$acno,$vdt,"cronjob_download");
			$file_name2 = $this->Excel_Model->chemist_invoice_report_excel($gstvno,$acno,$vdt,"cronjob_download");
			
			$subject = base64_encode($subject);
			$message = base64_encode($message);
			$email_function = "invoice";
			
			$mail_server = "drdinvoice";			

			$dt = array(
			'user_email_id'=>$user_email_id,
			'subject'=>$subject,
			'message'=>$message,
			'email_function'=>$email_function,
			'file_name1'=>$file_name1,
			'file_name2'=>$file_name2,
			'file_name_1'=>$file_name_1,
			'file_name_2'=>$file_name_2,
			'mail_server'=>$mail_server,
			);
			$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
		}
	}
	
	
	/****************04-02-2020*********************/
	public function staff_invoice_whatsapp_messsage()
	{
		error_reporting(0);
		$row = $this->db->query("select tbl_staffdetail_other.id,tbl_staffdetail.staffname,tbl_staffdetail.mobilenumber,tbl_staffdetail.division,tbl_staffdetail.compcode from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.whatsapp_message='1' and tbl_staffdetail_other.whatsapp_status='0'")->row();
		if($row->mobilenumber!="")
		{
			$id 		= $row->id;
			$division 	= $row->division;
			$compcode 	= $row->compcode;
			$this->db->query("update `tbl_staffdetail_other` set whatsapp_status=1 where id='$id'");
			
			$result1 = $this->db->query("SELECT gstvno,acno,vdt,compcode,division FROM `tbl_sales_staff` where whatsapp_message=0 and division='$division' and compcode='$compcode' order by compcode,division asc limit 50")->result();
			foreach($result1 as $row1)
			{
				$gstvno = $row1->gstvno;
				$acno 	= $row1->acno;
				$vdt 	= $row1->vdt;		
			
				if($row->staffname!="")
				{
					$staff_name 	= $row->staffname;
					$staff_mobile 	= $row->mobilenumber;
					//$staff_mobile 	= "9530005050";
					
					$row3 = $this->db->query("select name,altercode,mobile from tbl_acm where code='$acno' and slcd='CL'")->row();
					$acm_name 	= $row3->name;
					$altercode 	= $row3->altercode;
					$acm_mobile	= $row3->mobile;
					if($acm_mobile)
					{
						$acm_mobile = "Mobile: *$acm_mobile*";
					}
					
					$wdt = "";
					$result2 = $this->db->query("SELECT item_name,qty FROM `tbl_sales_staff` where compcode='$compcode' and division='$division' and gstvno='$gstvno' and acno='$acno' and vdt='$vdt'")->result();
					foreach($result2 as $row2)
					{
						$wdt.= "\\n \\nItem:".$row2->item_name." Qty:".round($row2->qty);
					}
				
					$staff_mobile = "+91".$staff_mobile;
					$message = "Hi $staff_name, \\n \\nFollowing medicines from your division have been billed to *$acm_name ($altercode)* $acm_mobile via Invoice number *$gstvno* $wdt \\n \\n*D.R.DISTRIBUTORS PVT LTD.* ";
					//$this->Email_Model->whatsapp_message("+917303229909",$message,$altercode);
					$this->Email_Model->whatsapp_message($staff_mobile,$message,$altercode);
				}
				$this->db->query("update `tbl_sales_staff` set whatsapp_message=1 where compcode='$compcode' and division='$division' and gstvno='$gstvno' and acno='$acno' and vdt='$vdt'");
			}
		}
		else
		{
			$this->db->query("update `tbl_staffdetail_other` set whatsapp_status=0");
		}
	}
	/*****************30-01-2020***********************/
	public function corporate_daily_report()
	{
		error_reporting(0);
		$time 	= time();
		$daily_date = date("Y-m-d", $time);
		
		$date	= date("Y-m-d", strtotime("-1 days", $time));
		$year 	= date("Y", strtotime("-1 days", $time));
		$month 	= date("m", strtotime("-1 days", $time));
		$d1 	= "01".date("-M-Y",strtotime("-1 days", $time));
		$d2 	= date("d-M-Y",strtotime("-1 days", $time));
		$vdt1 	= date("Y-m-",strtotime("-1 days", $time))."01";
		$vdt2 	= date("Y-m-d",strtotime("-1 days", $time));
		
		$result = $this->db->query("select tbl_staffdetail.id,tbl_staffdetail.division,tbl_staffdetail.compcode,tbl_staffdetail.code,tbl_staffdetail.memail,tbl_staffdetail_other.item_wise_report_daily_email,tbl_staffdetail_other.chemist_wise_report_daily_email,tbl_staffdetail_other.stock_and_sales_analysis_daily_email from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.daily_date='$date' limit 100")->result();
		foreach($result as $row)
		{
			$from 	= $date;
			$to 	= $date;
			
			$user_session  = $row->id;
			$user_division = $row->division;
			$user_compcode = $row->compcode;
			$code	= $row->code;
			$user_email_id = $row->memail;
			$item_wise_report_daily_email = $row->item_wise_report_daily_email;
			$chemist_wise_report_daily_email = $row->chemist_wise_report_daily_email;
			$stock_and_sales_analysis_daily_email = $row->stock_and_sales_analysis_daily_email;

			if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
			}
			else{
				$user_email_id="";
			}
			
			if($item_wise_report_daily_email=="0" && $chemist_wise_report_daily_email=="0" && $stock_and_sales_analysis_daily_email=="0")
			{
				$user_email_id="";
			}
			echo "hello<br>";
			if($user_email_id!="")
			{		
				$file_name_1 = $file_name_2 = $file_name_3 = "";
				$file_name1  = $file_name2 = $file_name3 = "";
				if($item_wise_report_daily_email=="1")
				{
					$file_name_1= "Item-Wise-Customer-Wise-Sales.xls";
					$file_name1 = $this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download");
				}
				
				if($chemist_wise_report_daily_email=="1")
				{
					$file_name_2= "Customer-Item-Wise-Sales.xls";
					$file_name2 = $this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download");
				}
				
				if($stock_and_sales_analysis_daily_email=="1")
				{
					/*$file_name_3= "Stock-And-Sales-Analysis.xls";
					$file_name3 = $this->Excel_Model->staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$year,$month,$d1,$d2,$vdt1,$vdt2,"cronjob_download");*/
				}
				
				if($file_name1=="" && $file_name2=="" && $file_name3=="")
				{
					// jab 3no file empty aya to
				}
				else
				{
					$subject = "DRD Daily Report || D.R.DISTRIBUTORS PVT";
					$message = "Secondary sales data from D R Distributors Pvt Ltd , please see the attachment.<br><br>D.R.DISTRIBUTORS PVT LTD.";
					
					$subject = base64_encode($subject);
					$message = base64_encode($message);
					$email_function = "corporate_daily_report";
					$mail_server = "gmail";
			
					$dt = array(
					'user_email_id'=>$user_email_id,
					'subject'=>$subject,
					'message'=>$message,
					'email_function'=>$email_function,
					'file_name1'=>$file_name1,
					'file_name2'=>$file_name2,
					'file_name3'=>$file_name3,
					'file_name_1'=>$file_name_1,
					'file_name_2'=>$file_name_2,
					'file_name_3'=>$file_name_3,
					'mail_server'=>$mail_server,
					);
					$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
				}
			}
			
			$this->db->query("update tbl_staffdetail_other set daily_date='$daily_date' where code='$code'");
		}
	}
	/*****************30-01-2020*******************/
	public function corporate_monthly_report()
	{
		error_reporting(0);
		$time 	= time();
		$date 	= date("Y-m-d", $time);
		$monthly= date("m", $time);
		$month	= date("m", strtotime("-1 month", $time));	
		$year  	= date("Y", strtotime("-1 month", $time));
		$date 	= "$year-{$month}";
		$ts 	= strtotime($date);
		$from 	= date('Y-m-01',$ts);
		$to 	= date('Y-m-t',$ts);
		
		$result = $this->db->query("select tbl_staffdetail.id,tbl_staffdetail.division,tbl_staffdetail.compcode,tbl_staffdetail.code,tbl_staffdetail.memail,tbl_staffdetail_other.item_wise_report_monthly_email,tbl_staffdetail_other.chemist_wise_report_monthly_email from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.monthly='$month' limit 2")->result();
		foreach($result as $row)
		{
			$user_session  = $row->id;
			$user_division = $row->division;
			$user_compcode = $row->compcode;
			$code	= $row->code;
			$user_email_id = $row->memail;
			$item_wise_report_monthly_email = $row->item_wise_report_monthly_email;
			$chemist_wise_report_monthly_email = $row->chemist_wise_report_monthly_email;
			
			if (filter_var($user_email_id, FILTER_VALIDATE_EMAIL)) {
		
			}
			else{
				$user_email_id="";
			}
			
			if($item_wise_report_monthly_email=="0" && $chemist_wise_report_monthly_email=="0")
			{
				$user_email_id="";
			}
			
			if($user_email_id!="")
			{
				$file_name_1 = $file_name_2 = $file_name_3 = "";
				$file_name1  = $file_name2 = $file_name3 = "";
				if($item_wise_report_monthly_email=="1")
				{
					$file_name_1= "Item-Wise-Customer-Wise-Sales.xls";
					$file_name1 = $this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download");
				}
				
				if($chemist_wise_report_monthly_email=="1")
				{
					$file_name_2= "Customer-Item-Wise-Sales.xls";
					$file_name2 = $this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,"cronjob_download");
				}
				
				if($file_name1=="" && $file_name2=="")
				{
					// jab dono file empty aya to
				}
				else
				{
					$subject = "DRD Monthly Report || D.R.DISTRIBUTORS PVT";
					$message = "Secondary sales data from D R Distributors Pvt Ltd , please see the attachment.<br><br>D.R.DISTRIBUTORS PVT LTD.";
					
					$subject = base64_encode($subject);
					$message = base64_encode($message);
					$email_function = "corporate_monthly_report";
					$mail_server = "gmail";
					
					$dt = array(
					'user_email_id'=>$user_email_id,
					'subject'=>$subject,
					'message'=>$message,
					'email_function'=>$email_function,
					'file_name1'=>$file_name1,
					'file_name2'=>$file_name2,
					'file_name_1'=>$file_name_1,
					'file_name_2'=>$file_name_2,
					'mail_server'=>$mail_server,
					);
					$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
				}					
			}
			
			$this->db->query("update tbl_staffdetail_other set monthly='$monthly' where code='$code'");
		}
	}
	
	/*****************30-01-2020*******************/
	public function low_stock_alert_email($subject,$message)
	{
		error_reporting(0);
		$subject = base64_encode($subject);
		$message = base64_encode($message);
		$email_function = "low_stock_alert";
		$mail_server = "gmail";
		
		$row = $this->db->query("select * from tbl_email where email_function='$email_function'")->row();
		$user_email_id = $row->email;

		$dt = array(
		'user_email_id'=>$user_email_id,
		'subject'=>$subject,
		'message'=>$message,
		'email_function'=>$email_function,
		'mail_server'=>$mail_server,
		);
		$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
	}	
	
	/***********13-02-2020********************************/
	
	function send_android_notification_firebase()
	{
		error_reporting(0);
		define('API_ACCESS_KEY', 'AAAAdZCD4YU:APA91bFjmo0O-bWCz2ESy0EuG9lz0gjqhAatkakhxJmxK1XdNGEusI5s_vy7v7wT5TeDsjcQH0ZVooDiDEtOU64oTLZpfXqA8EOmGoPBpOCgsZnIZkoOLVgErCQ68i5mGL9T6jnzF7lO');
		
		$time = time();
		$date = date("Y-m-d",$time);
		
		$query = $this->db->query("select * from tbl_new_notification where firebase_status='0' and date='$date' and device_id='default' limit 50")->result();
		foreach($query as $row)
		{
			$id = $row->id;
			$user_type 	= $row->user_type;
			$chemist_id = $row->chemist_id;
			$title 		= base64_decode($row->title);
			$message    = base64_decode($row->message);
			$funtype 	= $row->funtype;
			$itemid 	= $row->itemid;
			$division 	= $row->division;
			$image1		= $row->image;
			if($funtype=="2")
			{
				$itemid = $row->compid;
				$row1   =  $this->db->query("select company_full_name from tbl_medicine where compcode='$itemid'")->row();
				$company_full_name = base64_decode($row1->company_full_name);
				
				$row1  =  $this->db->query("select image from tbl_featured_brand where compcode='$itemid'")->row();
				if($row1->image!=""){
					$image =   base_url()."uploads/manage_featured_brand/photo/resize/".$row1->image;
				}
				else{
					$image = "http://drdmail.xyz/uploads/manage_users/photo/photo_1562659909.png";
				}
			}
			
			if($image1!="")
			{
				$image =   base_url()."uploads/manage_notification/photo/resize/".$image1;
			}
			
			if($image=="")
			{
				$image = "not";
			}
			if($company_full_name=="")
			{
				$company_full_name = "not";
			}
			
			$this->db->query("update tbl_new_notification set firebase_status='1' where firebase_status='0' and id='$id'");
			
			$query1 = $this->db->query("select firebase_token from tbl_android_device_id where chemist_id='$chemist_id' and user_type='$user_type'")->result();
			foreach($query1 as $row1)
			{
				$token = $row1->firebase_token;
				$data = array
				(
					'id'=>$id,
					'title'=>$title,
					'message'=>$message,
					'funtype'=>$funtype,
					'itemid'=>$itemid,
					'division'=>$division,
					'company_full_name'=>$company_full_name,
					'image'=>$image,
				);
					
				$fields = array
				(
					'to'=>$token,
					'data'=>$data,
				);

				$headers = array
				(
					'Authorization: key=' . API_ACCESS_KEY,
					'Content-Type: application/json'
				);
				#Send Reponse To FireBase Server	
				$ch = curl_init();
				curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
				curl_setopt( $ch,CURLOPT_POST, true );
				curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
				curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
				curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
				curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
				$result = curl_exec($ch);
				echo $result;
				curl_close($ch);
			}
		}
	}
	
	/***********03-04-2020********************************/
	
	function get_email_send_email_id($count,$newtype)
	{
		$query = $this->db->query("select * from tbl_gmail_username_password where emaillimit<180 and newtype='$newtype'")->row();
		if($query->id!="")
		{
			$mail_server 	= $query->mail_server; 
			$id 			= $query->id;
			$count 			= $query->emaillimit + $count;
			$this->db->query("update tbl_gmail_username_password set emaillimit='$count' where id='$id'");
		}
		return $mail_server;
	}
	
	function send_email_message()
	{
		//error_reporting(0);
		$this->db->limit(1);
		$this->db->order_by('id','desc');
		$query = $this->db->get("tbl_email_send")->result();
		
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		print_r($query);
		foreach($query as $row)
		{
			$id 			= $row->id;
			$user_email_id 	= $row->user_email_id;
			$subject 		= base64_decode($row->subject);
			$message 		= base64_decode($row->message);
			$email_function = $row->email_function;
			$file_name1 	= $row->file_name1;
			$file_name2 	= $row->file_name2;
			$file_name3 	= $row->file_name3;
			$file_name_1 	= $row->file_name_1;
			$file_name_2 	= $row->file_name_2;
			$file_name_3 	= $row->file_name_3;
			$mail_server 	= $row->mail_server;
			$email_other_bcc= $row->email_other_bcc;
			if($row->email_other_bcc=="")
			{
				$email_other_bcc="";
			}
			
			$addreplyto 		= "vipul@drdindia.com";
			$addreplyto_name 	= "Vipul DRD";
			$server_email 		= "kapil707sharma@gmail.com";
			$server_email_name 	= "kapil";
			$email1 			= "kapil707sharma@gmail.com";
			$email_bcc 			= "kapil7071@gmail.com";
			$live_or_demo 		= "live";
			
			$email->AddReplyTo($addreplyto,$addreplyto_name);
			$email->SetFrom($server_email,$server_email_name);
			
			$email->Subject   	= $subject;
			$email->Body 		= $message;		
			if($live_or_demo=="Demo")
			{
				$email->AddAddress($email1);
				$email_bcc = explode (",", $email_bcc);
				foreach($email_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}
			else
			{
				$email->AddAddress($user_email_id);
				$email->addBcc($email1);
				$email_bcc = explode (",", $email_bcc);
				foreach($email_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
				$email_other_bcc = explode (",", $email_other_bcc); 				
				foreach($email_other_bcc as $email_other_bcc_ok)
				{
					$email->addBcc($email_other_bcc_ok->memail);
				}
			}
			if($file_name1)
			{
				if($file_name_1)
				{
					$email->addAttachment($file_name1,$file_name_1);
				}
				else
				{
					$email->addAttachment($file_name1);
				}
			}
			if($file_name2)
			{
				if($file_name_2)
				{
					$email->addAttachment($file_name2,$file_name_2);
				}
				else
				{
					$email->addAttachment($file_name2);
				}
			}
			if($file_name3)
			{
				if($file_name_3)
				{
					$email->addAttachment($file_name3,$file_name_3);
				}
				else
				{
					$email->addAttachment($file_name3);
				}
			}
			
			//$this->db->query("delete from tbl_email_send where id='$id'");
			
			$email->IsHTML(true);	

			$email->IsSMTP();
			$email->SMTPAuth   = true; 
			$email->SMTPSecure = "ssl";  //tls
			$email->Host       = "smtpcorp.com";
			$email->Port       = 2525;
			$email->Username   = "send@drdindia.com";
			$email->Password   = "DRD#123";
			
			if($email->Send()){
				echo "Mail Sent";
			}
			else{
				echo "Mail Failed";
			}
			if($file_name1)
			{
				//unlink($file_name1);
			}
			if($file_name2)
			{
				//unlink($file_name2);
			}
			if($file_name3)
			{
				//unlink($file_name3);
			}
		}
	}
}