<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Message_Model extends CI_Model
{
	public function tbl_whatsapp_email_fail($number,$message,$altercode)
	{
		$where = array('altercode'=>$altercode);
		$row = $this->Scheme_Model->select_row("tbl_whatsapp_email_fail",$where,'','');
		if($row->id=="")
		{
			$this->db->query("insert into tbl_whatsapp_email_fail set altercode='$altercode',mobile='$number',message='$message'");
		}
	}
	
	public function insert_whatsapp_message($mobile,$message,$altercode)
	{
		$time = time();
		$date = date("Y-m-d",$time);

		$dt = array(
		'mobile'=>$mobile,
		'message'=>base64_encode($message),
		'chemist_id'=>$altercode,
		'time'=>$time,
		'date'=>$date,
		);
		$this->Scheme_Model->insert_fun("tbl_whatsapp_message",$dt);
	}
	
	public function send_whatsapp_message()
	{		
		$whatsapp_key = "531fe5caf0e132bdb6000bf01ed66d8cfb75b53606cc8f6eed32509d99d74752f47f288db155557e";
		
		$this->db->limit(50);
		$query = $this->db->get("tbl_whatsapp_message")->result();
		foreach($query as $row)
		{
			$mid 			= $row->id;
			$mobile 		= $row->mobile;
			$media 			= $row->media;
			$message 		= base64_decode($row->message);
			$message 		= str_replace("<br>","\\n \\n",$message);
			
			$chemist_id 	= $row->chemist_id;
			$this->db->query("DELETE FROM `tbl_whatsapp_message` WHERE id='$mid'");
		
			if($media!="")
			{
				$parmiter = '{"phone": "'.$mobile.'","message": "'.$message.'","media": { "file": "'.$media.'" }}';
			}
			if($media=="")
			{
				$parmiter = "{\"phone\":\"$mobile\",\"message\":\"$message\"}";
			}

			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => "https://api.wassi.chat/v1/messages",
			CURLOPT_RETURNTRANSFER=>true,
			CURLOPT_ENCODING =>"",
			CURLOPT_MAXREDIRS =>10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION =>CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS =>$parmiter,
			CURLOPT_HTTPHEADER =>array("content-type: application/json","token:$whatsapp_key"),));
			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				echo "cURL Error #:" . $err;
				$err = "Number stored is : $mobile";
				$this->Message_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
			} else {
				//echo $response;
				$someArray = json_decode($response,true);
				if($someArray["status"]=="400"||$someArray["status"]=="401"||$someArray["status"]=="409"||$someArray["status"]=="500"||$someArray["status"]=="501"||$someArray["status"]=="503")
				{
					$err = "Number stored is : $mobile";
					$this->Message_Model->tbl_whatsapp_email_fail($mobile,$err,$altercode);
				}
			}
		}
	}

	function send_email_message()
	{
		//error_reporting(0);
		$this->db->limit(1);
		$this->db->order_by('id','asc');
		$query = $this->db->get("tbl_email_send")->result();
		
		
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		//print_r($query);
		foreach($query as $row)
		{
			$id 			= $row->id;
			$user_email_id 	= $row->user_email_id;
			$subject 		= base64_decode($row->subject);
			$message 		= base64_decode($row->message);
			$file_name1 	= $row->file_name1;
			$file_name2 	= $row->file_name2;
			$file_name3 	= $row->file_name3;
			$file_name_1 	= $row->file_name_1;
			$file_name_2 	= $row->file_name_2;
			$file_name_3 	= $row->file_name_3;
			$mail_server 	= $row->mail_server;
			$email_other_bcc= $row->email_other_bcc;
			$email_function= $row->email_function;
			if($row->email_other_bcc=="")
			{
				$email_other_bcc="";
			}
			
			$addreplyto 		= "vipul@drdindia.com";
			$addreplyto_name 	= "Vipul DRD";
			$server_email 		= "send@drdindia.com";
			$server_email_name 	= "DRD Mail";
			/*$email1 			= "kapil707sharma@gmail.com";
			$email_bcc 			= "kapil7071@gmail.com";*/
			if($email_function=="invoice")
			{
				$server_email_name 	= "DRD Invoice";
			}
			
			$email->AddReplyTo($addreplyto,$addreplyto_name);
			$email->SetFrom($server_email,$server_email_name);
			
			$email->Subject   	= $subject;
			$email->Body 		= $message;		
			
			$email->IsHTML(true);
			if($live_or_demo=="Demo")
			{
				$email->AddAddress($user_email_id);
				$email_other_bcc = explode (",", $email_other_bcc);
				foreach($email_other_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}
			else
			{
				$email->AddAddress($user_email_id);
				//$email->addBcc($mail_server);
				$email_other_bcc = explode (",", $email_other_bcc);
				foreach($email_other_bcc as $bcc)
				{
					$email->addBcc($bcc);
				}
			}
			if($file_name1)
			{
				if($file_name_1)
				{
					$email->addAttachment($file_name1,$file_name_1);
				}
				else
				{
					$email->addAttachment($file_name1);
				}
			}
			if($file_name2)
			{
				if($file_name_2)
				{
					$email->addAttachment($file_name2,$file_name_2);
				}
				else
				{
					$email->addAttachment($file_name2);
				}
			}
			if($file_name3)
			{
				if($file_name_3)
				{
					$email->addAttachment($file_name3,$file_name_3);
				}
				else
				{
					$email->addAttachment($file_name3);
				}
			}
			
			/************************************************/
			$this->db->query("delete from tbl_email_send where id='$id'");
			/************************************************/

			$email->IsSMTP();
			$email->SMTPAuth   = true; 
			$email->SMTPSecure = "tls";  //tls
			$email->Host       = "smtpcorp.com";
			$email->Port       = 2525;
			$email->Username   = "send@drdindia.com";
			$email->Password   = "DRD#123";
			if($email->Send()){
				echo "Mail Sent";
			}
			else{
				echo "Mail Failed";
			}
			if($file_name1)
			{
				unlink($file_name1);
			}
			if($file_name2)
			{
				unlink($file_name2);
			}
			if($file_name3)
			{
				unlink($file_name3);
			}
		}
	}
}