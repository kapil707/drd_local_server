<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit', '-1');
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');
ini_set('max_execution_time', 36000);
require_once APPPATH."/third_party/PHPExcel.php";
class Cronjob_page extends CI_Controller 
{
	public function test_email()
	{
		$this->load->library('phpmailer_lib');
		$email = $this->phpmailer_lib->load();
		
		$subject = "drd local test";
		$message = "drd local test";
		
		$addreplyto 		= "vipul@drdindia.com";
		$addreplyto_name 	= "Vipul DRD";
		$server_email 		= "kapil707sharma@gmail.com";
		$server_email_name 	= "kapil";
		$email1 			= "kapil707sharma@gmail.com";
		$email_bcc 			= "kapil7071@gmail.com";
		
		$email->AddReplyTo($addreplyto,$addreplyto_name);
		$email->SetFrom($server_email,$server_email_name);
		$email->AddAddress($email1);
		
		$email->Subject   	= $subject;
		$email->Body 		= $message;		
		
		$email->IsHTML(true);	

		$email->IsSMTP();
		$email->SMTPAuth   = true; 
		$email->SMTPSecure = "tls";  //tls
		$email->Host       = "smtpcorp.com";
		$email->Port       = 2525;
		$email->Username   = "send@drdindia.com";
		$email->Password   = "DRD#123";
		
		if($email->Send()){
			echo "Mail Sent";
		}
	}

	public function send_email_message()
	{
		$this->Email_Model->send_email_message();
	}
	
	public function Corporate_daily_report()
	{
		$this->Email_Model->send_email_message();
		
		$monthdate = date('m');
		$date 	= date('Y-m');
		$year  	= date('Y');
		$date 	= "$year-{$monthdate}";
		$ts 	= strtotime($date);
		$from 	= date('Y-m-01',$ts);
		$to 	= date('Y-m-t',$ts);
		
		$time  = time();
		$from1 	= date('Y-m-d', strtotime("-1 days", $time));
		$to1 	= date('Y-m-d', strtotime("-1 days", $time));
		
		$daily_date = date('Y-m-d');		
		
		$daily_date1  = date("Y-m-d", strtotime("+1 days", $time));

		$row = $this->db->query("select stock_and_sales_analysis_daily_email,tbl_staffdetail_other.status,tbl_staffdetail.`compcode`,tbl_staffdetail.`company_full_name`,tbl_staffdetail.`division`,tbl_staffdetail.`id`,tbl_staffdetail_other.`id` as id1,tbl_staffdetail.`code` from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail_other.daily_date='$daily_date' limit 1")->row();		
		if($row->id!="")
		{			
			$user_session  = $row->id;
			$user_division = $row->division;
			$user_compcode = $row->compcode;
			$company_full_name = $row->company_full_name;
			
			$id1  = $row->id1;
			
			$this->db->query("update tbl_staffdetail_other set daily_date='$daily_date1' where id='$id1'");
			
			$file_name1 = $file_name2 = $file_name3 = "";
			$file_name_1 = $file_name_2 = $file_name_3 = "";
			if($row->stock_and_sales_analysis_daily_email=="1")
			{
				$file_name1  = $this->Excel_Model->staff_download_stock_and_sales_analysis($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_1 = "DRD-Sales-and-stock-report.xls";
			}
			
			if($row->item_wise_report_daily_email=="1")
			{
				$file_name2  = $this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_2 = "DRD-Item-wise-report.xls";
			}
			
			if($row->chemist_wise_report_daily_email=="1")
			{
				$file_name3  = $this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from1,$to1,"cronjob_download");
				$file_name_3 = "DRD-Chemist-wise-report.xls";
			}
			
			if($file_name1!="" || $file_name2!="" || $file_name3!="")
			{
				$subject = "Daily Report ".ucwords(strtolower($company_full_name))." (".$user_division.")";
				$message = "Please Find Attachment...";
				
				$subject = base64_encode($subject);
				$message = base64_encode($message);
				
				$user_email_id 		= "vipul@drdindia.com";
				$email_other_bcc 	= "kapil707sharma@gmail.com";

				$dt = array(
				'user_email_id'=>$user_email_id,
				'subject'=>$subject,
				'message'=>$message,
				'file_name1'=>$file_name1,
				'file_name_1'=>$file_name_1,
				'file_name2'=>$file_name2,
				'file_name_2'=>$file_name_2,
				'file_name3'=>$file_name3,
				'file_name_3'=>$file_name_3,
				'email_other_bcc'=>$email_other_bcc,
				);
				$this->Scheme_Model->insert_fun("tbl_email_send",$dt);
			}
		}
	}
}