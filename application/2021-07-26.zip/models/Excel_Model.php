<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Excel_Model extends CI_Model
{
	/*************************staff reports*****************************/
	public function staff_download_item_wise_report($session,$division,$compcode,$from,$to,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		$from1 	= date("d-M-Y",strtotime($from));
		$to1 	= date("d-M-Y",strtotime($to));

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A5','')
		->setCellValue('B5','CODE')
		->setCellValue('C5','CUSTOMER')
		->setCellValue('D5','QTY')
		->setCellValue('E5','FREE')
		->setCellValue('F5','AMOUNT')
		->setCellValue('G5','ADDRESS')
		->setCellValue('H5','MOBILE');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(6);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(99);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(64);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "F2/6, OKHLA INDUSTRIAL AREA, PHASE 1, NEW DELHI 110020");
		$sheet->setCellValueByColumnAndRow(0, 3, "Item Wise - Customer Wise Sale");
		$sheet->setCellValueByColumnAndRow(0, 4, "From :$from1 To : $to1");
		$sheet->mergeCells('A1:H1');
		$sheet->mergeCells('A2:H2');
		$sheet->mergeCells('A3:H3');
		$sheet->mergeCells('A4:H4');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 18,'bold' => FALSE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '398000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray(array('font' => array('size' => 15,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));			
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A5:H5')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));	
		
		/*$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
		$acm_josn	 	= $this->Scheme_Model->acm_josn_read();*/
		
		$myint_i = 0;
		$query = $this->Corporate_Model->item_wise_report($division,$compcode,$from,$to);
		$rowCount 		= 6;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$itm_c1 = $itm_c2 =0;
		$itm_c3 = $itm_c4 =0;
		$showone = 0;
		$fileok = 0;
		foreach($query as $row)
		{
			$fileok = 1;
			$itemc 	= $row->itemc;
			
			$itm_c3 = $row->itemc;
			if($itm_c3!=$itm_c4)
			{
				if($showone!=0)
				{
					$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total");
					$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty);
					$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free);
					$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt);
					
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
					$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
					$rowCount++;
				}
			}
			$showone++;
			
			$itm_c1 = $row->itemc;
			if($itm_c1!=$itm_c2)
			{
				$itm_c2 = $row->itemc;
				$itm_c4 = $row->itemc;
				$sheet->mergeCells('A'.$rowCount.':H'.$rowCount);
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Item : ".$row->name." Packing : ".$row->pack." Current Stock : ".round($row->batchqty));
				$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));		
				$rowCount++;
				
				$total_qty 	= 0;
				$total_free	= 0;
				$total_amt 	= 0;
			}
			
			$c_name 		= $row->c_name;
			$c_address 		= $row->address;
			$c_mobile 		= $row->mobile;
			$c_id 			= $row->altercode;
			
			if($row->vtype=="SR")
			{
				$row->qty 		= 0 - $row->qty;
				$row->netamt 	= 0 - $row->netamt;
			}
				
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$c_id);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$c_name);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->fqty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->netamt);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$c_address);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$c_mobile);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => FALSE,'name'  => 'Calibri')));
			$rowCount++;
			
			$total_qty 	= $total_qty 	+ $row->qty;
			$total_free	= $total_free 	+ $row->fqty;
			$total_amt 	= $total_amt 	+ $row->netamt;
			
			$total_qty1	= $total_qty1	+ $row->qty;
			$total_free1= $total_free1 	+ $row->fqty;
			$total_amt1	= $total_amt1 	+ $row->netamt;			
		}
		
		/**************last walay total ko show ke liya******************/
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total");
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '000080'],)));	
		$rowCount++;
		/*******************************************************/
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Grand Total:");
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty1);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_free1);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt1);
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A'.$rowCount.':H'.$rowCount)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Calibri','color' => ['rgb' => '973939'],)));
		
		$name = "Item Wise - Customer Wise Sale";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/item_wise_report_".$user_compcode."_".$user_division."_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}

	public function staff_download_chemist_wise_report($session,$division,$compcode,$from,$to,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		$tbl_staffdetail = $this->db->query("select company_full_name,comp_altercode from tbl_staffdetail where compcode='$compcode'")->row();
		
		$from1 	= date("d-M-Y",strtotime($from));
		$to1 	= date("d-M-Y",strtotime($to));

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A6','Party Name')
		->setCellValue('B6','Item Name')
		->setCellValue('C6','Pack')
		->setCellValue('D6','Qty.')
		->setCellValue('E6','Free')
		->setCellValue('F6','Amount')
		->setCellValue('G6','Address')
		->setCellValue('H6','Mobile');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(8);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(5);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(70);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "F2/6, OKHLA INDUSTRIAL AREA, PHASE 1, NEW DELHI 110020\nCIN : U51909DL2004PTC125295  GST No. : 07AABCD9532A1Z1");
		$sheet->setCellValueByColumnAndRow(0, 3, "CUSTOMER-ITEM WISE SALE");
		$sheet->setCellValueByColumnAndRow(0, 4, "From :$from1 To : $to1");
		$sheet->setCellValueByColumnAndRow(0, 5, "COMPANY : $tbl_staffdetail->comp_altercode  [ $tbl_staffdetail->company_full_name ]   DIVISION : $division");
		$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(25);
		$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
		$sheet->mergeCells('A1:H1');
		$sheet->mergeCells('A2:H2');
		$sheet->mergeCells('A3:H3');
		$sheet->mergeCells('A4:H4');
		$sheet->mergeCells('A5:H5');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 12,'bold' => FALSE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A6:H6')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('e68c85');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A6:H6')->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A6:H6')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$myint_i = 0;
		$query = $this->Corporate_Model->chemist_wise_report($division,$compcode,$from,$to);
		$rowCount 		= 7;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$fileok=0;
		foreach($query as $row)
		{		
			$fileok=1;
			if($row->vtype=="SR")
			{
				$row->qty 		= 0 - $row->qty;
				$row->netamt 	= 0 - $row->netamt;
			}
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row->c_name."(".$row->altercode.")");
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->name);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$row->pack);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$row->qty);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$row->fqty);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$row->netamt);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$row->address);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$row->mobile);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => false,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
			
			$total_qty 	= $total_qty 	+ $row->qty;
			$total_fqty = $total_fqty 	+ $row->fqty;
			$total_amt 	= $total_amt 	+ $row->netamt;
			$rowCount++;
		}
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total:");
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$total_qty);
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$total_fqty);
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$total_amt);
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A'.$rowCount.':H'.$rowCount)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '973939'],)));
		
		$name = "Customer - Item Wise Sale";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/chemist_wise_report_".$user_compcode."_".$user_division."_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}

	public function staff_download_stock_and_sales_analysis($session,$division,$compcode,$from,$to,$download_type)
	{
		$this->load->library('excel');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		error_reporting(0);
		ob_clean();
		
		$tbl_staffdetail = $this->db->query("select company_full_name,comp_altercode from tbl_staffdetail where compcode='$compcode'")->row();
		
		$from1 	= date("d-M-Y",strtotime($from));
		$to1 	= date("d-M-Y",strtotime($to));

		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A6','Item Name')
		->setCellValue('B6','Pack')
		->setCellValue('C6','Opening')
		->setCellValue('D6','Purchase')
		->setCellValue('E6','Sale')
		->setCellValue('F6','Sale Return')
		->setCellValue('G6','Others')
		->setCellValue('H6','Closing');
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
		
		$sheet = $objPHPExcel->getActiveSheet();
		$sheet->setCellValueByColumnAndRow(0, 1, "D.R.DISTRIBUTORS PVT.LTD.");
		$sheet->setCellValueByColumnAndRow(0, 2, "F2/6, OKHLA INDUSTRIAL AREA, PHASE 1, NEW DELHI 110020\nCIN : U51909DL2004PTC125295  GST No. : 07AABCD9532A1Z1");
		$sheet->setCellValueByColumnAndRow(0, 3, "SALE AND STOCK ANALYSIS");
		$sheet->setCellValueByColumnAndRow(0, 4, "From :$from1 To : $to1");
		$sheet->setCellValueByColumnAndRow(0, 5, "COMPANY : $tbl_staffdetail->comp_altercode  [ $tbl_staffdetail->company_full_name ]   DIVISION : $division");
		$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(25);
		$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setWrapText(true);
		$sheet->mergeCells('A1:H1');
		$sheet->mergeCells('A2:H2');
		$sheet->mergeCells('A3:H3');
		$sheet->mergeCells('A4:H4');
		$sheet->mergeCells('A5:H5');
		$sheet->getStyle('A1')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A2')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		$sheet->getStyle('A3')->getAlignment()->applyFromArray(
			array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,)
		);
		
		$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray(array('font' => array('size' => 12,'bold' => FALSE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->applyFromArray(array('font' => array('size' => 8,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));	
		$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setUnderline(true);		
		
		$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));		
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A6:H6')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('e68c85');
		
		$BStyle = array(
		  'borders' => array(
			'allborders' => array(
			  'style' => PHPExcel_Style_Border::BORDER_THIN
			)
		  )
		);
		$objPHPExcel->getActiveSheet()->getStyle('A6:H6')->applyFromArray($BStyle);
		$objPHPExcel->getActiveSheet()->getStyle('A6:H6')->applyFromArray(array('font' => array('size' => 10,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
		
		$myint_i = 0;
		$query = $this->Corporate_Model->stock_and_sales_analysis($division,$compcode,$from,$to);
		$rowCount 		= 7;
		$total_qty1 	= 0;
		$total_free1 	= 0;
		$total_amt1 	= 0;
		$fileok=0;
		foreach($query as $row)
		{		
			$fileok=1;
			
			$itemc = $row->code;
			/*$row12 = $this->db->query("select * from tbl_sales_and_stock where i_code='$itemc'")->row();
			$opening = 0;
			if(round($row12->stock)>0)
			{
				$opening = round($row12->stock);
				$closing1 = round($row12->closing_stock);
			}*/
			$opening		= round($row->TempOpqty);
			$closing1		= round($row->TempClqty);
			$purchase 		= round($row->purchase);
			$sale 			= round($row->sale);	
			$sale_return 	= round($row->sale_return);
			$other1			= round($row->other1);
			$other2 		= round($row->other2);
			
			$total_other = 0;
			if($row->other1_1=="")
			{
				$row->other1_1 = 0;
			}
			
			if($row->other2_1=="")
			{
				$row->other2_1 = 0;
			}
			
			$other = 0;			
			if($other2!=0)
			{		
				$other 			= $other1 - $other2;
				$total_other 	= $row->other1_1;
			}
			if($row->purchase1=="")
			{
				$row->purchase1 = 0;
			}
			$total_purchase = ($row->purchase1);	
			
			if($row->sale1=="")
			{
				$row->sale1 = 0;
			}
			$total_sale = ($row->sale1);
			
			if($row->sale_return1=="")
			{
				$row->sale_return1 = 0;
			}
			$total_sale_return = ($row->sale_return1);
			
			$closing 		= $opening + $purchase + $sale_return;
			$closing 		= $closing - $sale;
			$closing 		= $closing + $other;
			if($closing1=="0")
			{
				$closing 	= 0;
			}
			
			$total_opening = $opening * $row->prate;
			$total_closing = $closing * $row->prate;
			
			$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,$row->name);
			$objPHPExcel->getActiveSheet()->SetCellValue('B'.$rowCount,$row->pack);
			$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,$opening);
			$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,$purchase);
			$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,$sale);
			$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,$sale_return);
			$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,$other);
			$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,$closing);
			$objPHPExcel->getActiveSheet()->getStyle('H'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
			
			$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => false,'name'  => 'Arial','color' => ['rgb' => '000000'],)));
			
			$total_opening1 	= $total_opening1 	+ $total_opening;
			$total_purchase1 	= $total_purchase1 	+ $total_purchase;
			$total_sale1 		= $total_sale1 		+ $total_sale;
			$total_sale_return1 = $total_sale_return1+ $total_sale_return;
			$total_other1 		= $total_other1 	+ $total_other;
			$total_closing1 	= $total_closing1 	+ $total_closing;
			$rowCount++;
		}
		
		$objPHPExcel->getActiveSheet()->SetCellValue('A'.$rowCount,"Total:");
		$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount,round($total_opening1,2));
		$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount,round($total_purchase1,2));
		$objPHPExcel->getActiveSheet()->SetCellValue('E'.$rowCount,round($total_sale1,2));
		$objPHPExcel->getActiveSheet()->SetCellValue('F'.$rowCount,round($total_sale_return1,2));
		$objPHPExcel->getActiveSheet()->SetCellValue('G'.$rowCount,round($total_other1,2));
		$objPHPExcel->getActiveSheet()->SetCellValue('H'.$rowCount,round($total_closing1,2));
		
		$objPHPExcel->getActiveSheet()
        ->getStyle('A'.$rowCount.':H'.$rowCount)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB('FDFE9F');
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray($BStyle);
		
		$objPHPExcel->getActiveSheet()->getStyle('A'.$rowCount.':H'.$rowCount)->applyFromArray(array('font' => array('size' => 9,'bold' => TRUE,'name'  => 'Arial','color' => ['rgb' => '973939'],)));
		
		$name = "Sales And Stock Report";
		if($download_type=="direct_download")
		{
			$file_name = $name.".xls";
			
			//$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
			/*$objWriter->save('uploads_sales/kapilkifile.xls');*/
			
			header('Content-type: application/vnd.ms-excel');
			header('Content-Disposition: attachment; filename='.$file_name);
			header('Cache-Control: max-age=0');
			ob_start();
			$objWriter->save('php://output');
			$data = ob_get_contents();
		}
		if($download_type=="cronjob_download")
		{
			if($fileok==1)
			{
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');
				$file_name = "email_files/sales_and_stock_report_".$user_compcode."_".$user_division."_".time().".xls";
				$objWriter->save($file_name);
				return $file_name;
			}
			else
			{
				$file_name = "";
				return $file_name;
			}
		}
	}
}