<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?= constant('base_url2'); ?>assets/website/css/font-awesome.min.css"> 
<link href="<?= constant('base_url2'); ?>assets/website/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?= constant('base_url2'); ?>assets/website/css/style<?= constant('site_v') ?>.css" rel="stylesheet" type="text/css"/>
<link href="<?= constant('base_url2'); ?>assets/website/css/scrolling/css/amazon_scroller.css" rel="stylesheet" type="text/css"></link>
<script type="text/javascript" src="<?= constant('base_url2'); ?>assets/website/css/scrolling/js/amazon_scroller.js"></script>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+HK&display=swap" rel="stylesheet">
<body style="margin-top: 0px;">