<style>
body
{
	margin:0px;
	padding:0px;
}
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12 col-12">
			<div class="row">
				<div class="col-sm-8 col-12">
					Company : <?= base64_decode($_SESSION['user_compname']); ?>
					<br>
					From : 
					<?php
					$time 	= time();
					$d1 	= "01".date("-M-y",$time);
					$d2 	= date("d-M-y",$time);
					?>
					<?= $d1?> To: <?= $d2?>
				</div>
				<div class="col-sm-4 col-12">	
					<button type="submit" name="submit" class="btn btn-success btn-block downloadbtn" onclick="call_download()" style="display:none;">Download</button>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th width="150px;">Item</th>
							<th>Pack</th>
							<th>Opening</th>
							<th>Purchase</th>
							<th>Sale</th>
							<th>Sale Return</th>
							<th>Others</th>
							<th>Closing</th>
						</tr>
					</thead>
					<tbody class="load_page">
					
					</tbody>
					<tfoot class="load_page_tfoot">
					
					</tfoot>
				</table>
				<div class="load_page_loading">
					
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js" charset="UTF-8"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css">
  
<script>
$(document).ready(function(){
	call_page();
});
function call_page()
{
	user_session	=	'<?=$user_session?>';
	user_division	=	'<?=$user_division?>';
	user_compcode	=	'<?=$user_compcode?>';
	
	$(".load_more").hide();
	$(".load_page").html("");
	$(".load_page_loading").html('<h1><center><img src="<?= constant('base_url2'); ?>/img_v<?= constant('site_v') ?>/loading.gif" width="100px"></center></h1><h1><center>Loading....</center></h1>');
	$.ajax({
		type       : "POST",
		data       :  {user_session:user_session,user_division:user_division,user_compcode:user_compcode,} ,
		url        : "<?php echo base_url(); ?>corporate/stock_and_sales_analysis_api",
		cache	   : false,
		error: function(){
			$(".load_page_loading").html('<h1><img src="<?= constant('base_url2'); ?>img_v<?= constant('site_v') ?>/something_went_wrong.png" width="100%"></h1>');
		},
		success    : function(data){
			if(data!="")
			{
				$(".load_page_loading").html("");
			}
			var total_opening = 0;
			var total_purchase = 0;
			var total_sale = 0;
			var total_sale_return = 0;
			var total_other = 0;
			var total_closing = 0;
			$.each(data.items, function(i,item){	
				if (item){
					if(item.permission!="")
					{
						$(".load_page").append('<center>'+item.permission+'</center>');
					}
					else
					{
						total_opening	= total_opening + parseFloat(item.total_opening)
						total_purchase 	= total_purchase + parseFloat(item.total_purchase)
						total_sale 		= total_sale + parseFloat(item.total_sale)
						total_sale_return= total_sale_return + parseFloat(item.total_sale_return)
						total_other		= total_other + parseFloat(item.total_other)
						total_closing	= total_closing + parseFloat(item.total_closing)
						//$(".downloadbtn").show();
						$(".load_page").append('<tr><td class="cart_title">'+atob(item.item_name)+'</td><td class="cart_packing">'+atob(item.packing)+'</td><td class="cart_stock">'+(item.opening)+'</td><td>'+(item.purchase)+'</td><td>'+(item.sale)+'</td><td>'+(item.sale_return)+'</td><td>'+(item.other)+'</td><td>'+(item.closing)+'</td></tr>');
						$(".load_page_tfoot").html('<tr><td></td><td></td><td>'+total_opening+'</td><td>'+total_purchase+'</td><td>'+total_sale+'</td><td>'+total_sale_return+'</td><td>'+total_other+'</td><td>'+total_closing+'</td></tr>');
					}
				}
			});			
		}
	});
}
function call_download()
{
	$(".downloadbtn").hide();
	formdate = $(".formdate").val();
	todate   = $(".todate").val();
	if(formdate=="")
	{
		alert("Select Date from")
		return false;
	}
	if(todate=="")
	{
		alert("Select Date to")
		return false;
	}
	window.location.href = "<?php echo constant('api_url'); ?>api_website_html/staff_download_stock_and_sales_analysis/<?= $user_session; ?>/<?= $user_division; ?>/<?= $user_compcode; ?>";
	$(".downloadbtn").show(10000);
}
</script>