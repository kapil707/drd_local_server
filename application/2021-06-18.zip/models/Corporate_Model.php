<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Corporate_Model extends CI_Model  
{
	public function item_wise_report($division='',$compcode='',$from='',$to='')
	{
		$this->db->select('tbl_invoice_item.netamt,tbl_invoice.chemist_id,tbl_invoice.name,tbl_invoice.mobile,tbl_invoice_item.itemc,tbl_invoice_item.item_name,tbl_invoice_item.packing,tbl_invoice_item.vdt,tbl_invoice_item.qty,tbl_invoice_item.fqty');
		$this->db->from('tbl_invoice');
		$this->db->join('tbl_invoice_item','tbl_invoice.vno=tbl_invoice_item.vno');
		$this->db->where('tbl_invoice_item.division',$division);
		$this->db->where('tbl_invoice_item.compcode',$compcode);
		$this->db->where('tbl_invoice_item.vdt>=',$from);
		$this->db->where('tbl_invoice_item.vdt<=',$to);
		$this->db->order_by('item_name','asc');
		$query=$this->db->get();
		return $query->result();
	}
}  