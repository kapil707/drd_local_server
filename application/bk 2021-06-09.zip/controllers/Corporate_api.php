<?php
header("Content-type: application/json; charset=utf-8");
defined('BASEPATH') OR exit('No direct script access allowed');
class Corporate_api extends CI_Controller {
	
	public function login()
	{
		$data = json_decode(file_get_contents('php://input'),true);
		$items1 = $data["items"];
		foreach($items1 as $ks)
		{
			$user_name1 	= ($ks["user_name1"]);
			$user_password 	= ($ks["user_password"]);
			
			$query = $this->db->query("select tbl_staffdetail.compcode,tbl_staffdetail.division,tbl_staffdetail.id,tbl_staffdetail.code,tbl_staffdetail.degn as name, tbl_staffdetail.mobilenumber as mobile,tbl_staffdetail.memail as email,tbl_staffdetail_other.status,tbl_staffdetail_other.exp_date,tbl_staffdetail_other.password from tbl_staffdetail left join tbl_staffdetail_other on tbl_staffdetail.code = tbl_staffdetail_other.code where tbl_staffdetail.memail='$user_name1' and tbl_staffdetail.code=tbl_staffdetail_other.code limit 1")->row();
			if ($query->id!="")
			{
				if ($query->password == $user_password)
				{
					if($query->status==1)
					{
						$user_session 	= 	$query->id;
						$user_fname		= 	ucwords(strtolower($query->name));
						$user_code	 	= 	$query->code;
						$user_altercode	= 	$query->code;
						$user_type 		= 	"corporate";
						$user_return 	= 	"1";
						$user_alert 	= 	"Logged in Successfully";
						$user_division	= 	$query->division;
						$user_compcode	= 	$query->compcode;
						$user_compname	= 	"";
					}
					else
					{
						$user_alert = "Access Denied";
					}
				}
				else
				{
					$user_alert = "Incorrect Password";
				}
			}
$items .= <<<EOD
{"user_session":"{$user_session}","user_fname":"{$user_fname}","user_code":"{$user_code}","user_altercode":"{$user_altercode}","user_type":"{$user_type}","user_password":"{$user_password}","user_alert":"{$user_alert}","user_return":"{$user_return}","user_division":"{$user_division}","user_compcode":"{$user_compcode}"},
EOD;
if ($items != '') {
	$items = substr($items, 0, -1);
}
		}
?>{"items":[<?= $items;?>]}<?php
	}

	public function item_wise_report_api()
	{
		error_reporting(0);				
		date_default_timezone_set('Asia/Kolkata');
		$from 	= date("Y-m-d",strtotime($_GET["formdate"]));
		$to 	= date("Y-m-d",strtotime($_GET["todate"]));

		if($_GET["monthdate"]!="")
		{
			$date 	= date('Y-m');
			$year  	= date('Y');
			$date 	= "$year-{$_GET["monthdate"]}";
			$ts 	= strtotime($date);
			$from 	= date('Y-m-01',$ts);
			$to 	= date('Y-m-t',$ts);
		}
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select item_wise_report,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$item_wise_report = $row->item_wise_report;
		$status = $row->status;
		if($item_wise_report=="1" && $status=="1")
		{			
			//$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
			//$acm_josn 		= $this->Scheme_Model->acm_josn_read();
			echo "select tbl_invoice_item.item_name,tbl_invoice_item.item_code,tbl_invoice_item.itemc,tbl_invoice_item.packing,tbl_invoice_item.qty,tbl_invoice_item.fqty,tbl_invoice_item.netamt,tbl_invoice_item.vdt,tbl_invoice.name,tbl_invoice.mobile from tbl_invoice_item INNER JOIN tbl_invoice ON tbl_invoice.vno = tbl_invoice_item.vno where tbl_invoice_item.division='$division' and tbl_invoice_item.compcode='$compcode' and tbl_invoice_item.vdt>='$from' and tbl_invoice_item.vdt<='$to' order by item_name asc";die;
			$query = $this->db->query("select tbl_invoice_item.item_name,tbl_invoice_item.item_code,tbl_invoice_item.itemc,tbl_invoice_item.packing,tbl_invoice_item.qty,tbl_invoice_item.fqty,tbl_invoice_item.netamt,tbl_invoice_item.vdt,tbl_invoice.name,tbl_invoice.mobile from tbl_invoice_item INNER JOIN tbl_invoice ON tbl_invoice.vno = tbl_invoice_item.vno where tbl_invoice_item.division='$division' and tbl_invoice_item.compcode='$compcode' and tbl_invoice_item.vdt>='$from' and tbl_invoice_item.vdt<='$to' order by item_name asc")->result();
			$i = 0;
			foreach ($query as $value)
			{
				$name 		= $value->name;
				$address 	= $value->address;
				$mobile 	= $value->mobile;
				
				$item_code 		= $value->item_code;			
				/*$row2 = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
				$total_qty = $row2->batchqty;*/
				$c = count($medicine_josn);
				for($i=0;$i<$c;$i++)
				{
					if($medicine_josn[$i]["item_code"]==$item_code)
					{
						$total_qty = $medicine_josn[$i]["batchqty"];
					}
				}
				
				$i++;
				if($i%2==0) 
				{ 
					$css = "med_gray"; 
				} 
				else
				{
					$css = "med_gray1"; 
				}
				$item_code 		= $value->itemc;
				$item_name 		= base64_encode($value->item_name." PACK :".$value->packing." Quantity: ".$total_qty);
				$chemist_name 	= base64_encode($name);
				$chemist_address= ($address);
				$chemist_mobile	= base64_encode($mobile);
				$qty 			= round($value->qty);
				$fqty 			= round($value->fqty);
				$date			= date("d-M-Y", strtotime($value->vdt));
				$permission 	= "";
			
$items.= <<<EOD
{"css":"{$css}","item_code":"{$item_code}","item_name":"{$item_name}","acno":"{$acno}","chemist_name":"{$chemist_name}","chemist_address":"{$chemist_address}","chemist_mobile":"{$chemist_mobile}","qty":"{$qty}","fqty":"{$fqty}","date":"{$date}","permission":"{$permission}"},
EOD;
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function chemist_wise_report_api()
	{
		error_reporting(0);		
		date_default_timezone_set('Asia/Kolkata');
		$from 	= date("Y-m-d",strtotime($_GET["formdate"]));
		$to 	= date("Y-m-d",strtotime($_GET["todate"]));

		if($_GET["monthdate"]!="")
		{
			$date 	= date('Y-m');
			$year  	= date('Y');
			$date 	= "$year-{$_GET["monthdate"]}";
			$ts 	= strtotime($date);
			$from 	= date('Y-m-01',$ts);
			$to 	= date('Y-m-t',$ts);
		}
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select chemist_wise_report,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$chemist_wise_report = $row->chemist_wise_report;
		$status = $row->status;
		if($chemist_wise_report=="1" && $status=="1")
		{			
			//$medicine_josn 	= $this->Scheme_Model->medicine_josn_read();
			//$acm_josn 		= $this->Scheme_Model->acm_josn_read();
			$query = $this->db->query("select tbl_invoice.acno,tbl_invoice_item.item_name,tbl_invoice_item.item_code,tbl_invoice_item.itemc,tbl_invoice_item.packing,tbl_invoice_item.qty,tbl_invoice_item.fqty,tbl_invoice_item.netamt,tbl_invoice_item.vdt,tbl_invoice.name,tbl_invoice.mobile from tbl_invoice_item INNER JOIN tbl_invoice ON tbl_invoice.vno = tbl_invoice_item.vno where tbl_invoice_item.division='$division' and tbl_invoice_item.compcode='$compcode' and tbl_invoice_item.vdt>='$from' and tbl_invoice_item.vdt<='$to' order by acno asc")->result();
			$i = 0;
			foreach ($query as $value)
			{
				$acno 		= $value->acno;
				$name 		= $value->name;
				$address 	= $value->address;
				$mobile 	= $value->mobile;
				
				$i++;
				if($i%2==0) 
				{ 
					$css = "med_gray"; 
				} 
				else
				{
					$css = "med_gray1"; 
				}
				$item_code 		= $value->itemc;
				$item_name 		= base64_encode($value->item_name." PACK :".$value->packing." Quantity: ".$total_qty);
				$chemist_name 	= base64_encode($name);
				$chemist_address= ($address);
				$chemist_mobile	= base64_encode($mobile);
				$qty 			= round($value->qty);
				$fqty 			= round($value->fqty);
				$date			= date("d-M-Y", strtotime($value->vdt));
				$permission 	= "";
			
$items.= <<<EOD
{"css":"{$css}","item_code":"{$item_code}","item_name":"{$item_name}","acno":"{$acno}","chemist_name":"{$chemist_name}","chemist_address":"{$chemist_address}","chemist_mobile":"{$chemist_mobile}","qty":"{$qty}","fqty":"{$fqty}","date":"{$date}","permission":"{$permission}"},
EOD;
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function staff_download_item_wise_report($user_session,$user_division,$user_compcode,$formdate,$todate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		$from 	= date("Y-m-d",strtotime($formdate));
		$to 	= date("Y-m-d",strtotime($todate));		
		
		$this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function staff_download_item_wise_report_month($user_session,$user_division,$user_compcode,$monthdate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		
		$date 	= date('Y-m');
		$year  	= date('Y');
		$date 	= "$year-{$monthdate}";
		$ts 	= strtotime($date);
		$from 	= date('Y-m-01',$ts);
		$to 	= date('Y-m-t',$ts);
		
		$this->Excel_Model->staff_download_item_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$formdate,$todate)
	{
		error_reporting(0);
		$user_session  = base64_decode($user_session);
		$user_division = base64_decode($user_division);
		$user_compcode = base64_decode($user_compcode);
		$from 	= date("Y-m-d",strtotime($formdate));
		$to 	= date("Y-m-d",strtotime($todate));		
		
		$this->Excel_Model->staff_download_chemist_wise_report($user_session,$user_division,$user_compcode,$from,$to,"direct_download");
	}
	
	public function stock_and_sales_analysis_api()
	{
		error_reporting(0);
		$time 	= time();
		$year 	= date("Y",$time);
		$month 	= date("m",$time);	
		$d1 	= "01".date("-M-Y",$time);
		$d2 	= date("d-M-Y",$time);
		$vdt1 	= date("Y-m-",$time)."01";
		$vdt2 	= date("Y-m-d",$time);		
		
		$session	= $_GET['user_session'];
		$division 	= $_GET['user_division'];
		$compcode 	= $_GET['user_compcode'];
		
		$row = $this->db->query("select stock_and_sales_analysis,tbl_staffdetail_other.status from tbl_staffdetail,tbl_staffdetail_other where tbl_staffdetail.division='$division' and tbl_staffdetail.compcode='$compcode' and tbl_staffdetail.code=tbl_staffdetail_other.code and tbl_staffdetail.id='$session'")->row();
		$stock_and_sales_analysis = $row->stock_and_sales_analysis;
		$status = $row->status;
		if($stock_and_sales_analysis=="1" && $status=="1")
		{		
			$medicine_josn  		= $this->Scheme_Model->medicine_josn_read();
			$medicine_month_josn 	= $this->Scheme_Model->medicine_month_josn_read($year,$month);
		
			//$query = $this->db->query("select item_name,packing,batchqty,item_code from tbl_stock_of_medicine_month_to_month where division='$division' and compcode='$compcode' and year='$year' and month='$month' order by item_name asc")->result();
			$i = 0;
			$c = count($medicine_month_josn);
			for($i=0;$i<$c;$i++)
			{
				if($medicine_month_josn[$i]["division"]==$division && $medicine_month_josn[$i]["compcode"]==$compcode)
				{
					$item_name 	= $medicine_month_josn[$i]["item_name"];	
					$packing 	= $medicine_month_josn[$i]["packing"];	
					$batchqty 	= $medicine_month_josn[$i]["batchqty"];	
					$item_code 	= $medicine_month_josn[$i]["item_code"];	
					$i++;
					if($i%2==0) 
					{ 
						$css = "med_gray"; 
					} 
					else
					{
						$css = "med_gray1"; 
					}
					$item_name 		= base64_encode($item_name);
					$packing 		= base64_encode($packing);
					$qty 			= $batchqty;
					
					$sale 	= 0;
					$query1 = $this->db->query("select qty from tbl_sales_staff where item_code='$item_code' and division='$division' and compcode='$compcode' and vdt>='$vdt1' and vdt<='$vdt2'")->result();
					foreach($query1 as $row1)
					{
						$sale = $sale + $row1->qty;
					}
					
					$closing=0;
					/*$row = $this->db->query("select batchqty from tbl_medicine where item_code='$item_code'")->row();
					if($row->batchqty!="")
					{
						$closing = $row->batchqty;
					}*/
					$cs = count($medicine_josn);
					for($is=0;$is<$cs;$is++)
					{
						if($medicine_josn[$is]["item_code"]==$item_code)
						{
							$closing = $medicine_josn[$is]["batchqty"];
						}
					}
					$purchase = $qty - $closing;
					$purchase = $sale - $purchase;
					$permission = "";
$items.= <<<EOD
{"item_name":"{$item_name}","packing":"{$packing}","qty":"{$qty}","purchase":"{$purchase}","sale":"{$sale}","closing":"{$closing}","permission":"{$permission}"},
EOD;
				}
			}
		}
		else
		{
			$permission = "Please contact Vipul on 9899133989 and request access for the particular report.";
$items.= <<<EOD
{"permission":"{$permission}"},
EOD;
		}

if ($items != ''){
	$items = substr($items, 0, -1);
}
?>
{"items":[<?= $items;?>]}
		<?php
	}
	
	public function corporate_daily_report()
	{
		error_reporting(0);
		$this->Email_Model->corporate_daily_report();
	}
	
	public function corporate_monthly_report()
	{
		error_reporting(0);
		$this->Email_Model->corporate_monthly_report();
	}
	
	public function send_email_message()
	{
		$this->Email_Model->send_email_message();
	}
}