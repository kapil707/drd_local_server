<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('memory_limit','512M'); // This also needs to be increased in some cases. Can be changed to a higher value as per need)
ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288'); // Setting to 512M - for pdo_sqlsrv
class Drd_Invoice_Model extends CI_Model  
{
	var $mssql;
    function __construct()
    {
        parent::__construct();
        $this->mssql = $this->load->database ( 'my_mssql', TRUE );
    }

    public function test_ck(){
       //use $this->mssql instead of $this->db
       $query = $this->mssql->query('select * from acm')->row();
	   return $query;
       //...
    }

    function get_some_mysql_rows(){
       //use  $this->db for default 
       $query = $this->db->query('select * from mysql_table');
       //...
    }
	
	public function copy_invoice(){
		
		$mycode = 0;
		$row = $this->db->query("select vno from tbl_invoice order by id desc limit 1")->row();
		if($row->vno!="")
		{
			$mycode = $row->vno;
		}
		
		$vdt_ck = date("Y-m-d");
		$where = "sle.vdt='$vdt_ck'";
		if ($mycode != 0)
		{
			$newdtd = date("Y")."-04-01";
			$where = "sle.vno>'$mycode' and sle.vdt>='$newdtd'";
		}
		
		$result = $this->mssql->query("select top 50 sle.vdt,sle.vno,sle.pickedby,sle.checkedby,sle.deliverby,sle.vtype,sl.acno,sl.amt,sl.gstvno,a.name,a.email,a.altercode,a.mobile,sl.taxamt,a.address from Salepurchase1Extra as sle, Salepurchase1 as sl,acm as a where $where and (sle.Vtype='SB' or sle.Vtype='SR') and a.code=sl.acno and sl.Vno=sle.Vno and sl.vdt=sle.vdt order by sle.vno")->result();
		foreach($result as $row)
		{
			$vdt = $row->vdt;
			$vno = $row->vno;
			$pickedby = $row->pickedby;
			$checkedby = $row->checkedby;
			$deliverby = ""; // yha other query say add hota ha
			$vtype = $row->vtype;
			$date = date("Y-m-d");
			$acno = $row->acno;
			$amt = $row->amt;
			$gstvno = $row->gstvno;
			$name = $row->name;
			$email_id = $row->email;
			$chemist_id = $row->altercode;
			$mobile = $row->mobile;
			$taxamt = $row->taxamt;
			$address = $row->address;			
			
			$insert_query = "insert into tbl_invoice (vdt,vno,pickedby,checkedby,deliverby,vtype,date,acno,amt,gstvno,name,email_id,chemist_id,mobile,taxamt,address) values ('$vdt','$vno','$pickedby','$checkedby','$deliverby','$vtype','$date','$acno','$amt','$gstvno','$name','$email_id','$chemist_id','$mobile','$taxamt','$address')";
			
			$this->db->query($insert_query);
		}
	}
	
	public function check_delivery(){
		$date = date("Y-m-d");
		$result = $this->db->query("SELECT vno FROM `tbl_invoice` WHERE `date`='$date' and deliverby=''  ORDER BY RAND() limit 100")->result();
		foreach($result as $row)
		{
			$vno = $row->vno;
			$vno_ck.= " sl.vno='$vno' or";
		}
		if($vno_ck!="")
		{
			$vno_ck = substr($vno_ck, 0, -2);
			
			$result = $this->mssql->query("select sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile from salepurchase1extra as sl,salepurchase1 as s2,acm as a where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and sl.vdt='$date' and ($vno_ck)")->result();
			foreach($result as $row)
			{
				$pickedby 	= $row->pickedby;
				$checkedby 	= $row->checkedby;
				$deliverby 	= $row->deliverby;
				$gstvno 	= $row->gstvno;
				$vno        = $row->vno;
				$altercode 	= $row->altercode;
				$name 		= $row->name;
				$mobile 	= "+91".$row->mobile;
				if($deliverby!="")
				{
					$this->db->query("update tbl_invoice set pickedby='$pickedby',checkedby='$checkedby',deliverby='$deliverby' where gstvno='$gstvno' and vno='$vno'");
					
					$vdt = strtotime($row->vdt);
					$newdate = date('d-M-Y',$vdt);

					$url_link = "https://www.drdistributor.com/invoice/".$altercode."/".$gstvno;
					$android_link = "https://rb.gy/xo2qlk";

					$whatsapp_message = "Hi $name ($altercode)<br><br>Invoice No. *$gstvno*  for your Order Placed on $newdate has been generated and the packet is *out for delivery* with one of our delivery executives.<br><br>The order will reach you soon.<br>Regards <br>*D.R. Distributors Pvt. Ltd.*<br><br>You can check your invoice by clicking on $url_link <br><br>On laptop or pc you can visit following link to start placing orders https://rb.gy/alh73o <br><br>Please download our app from Google play store : ".$android_link;
					
					//$mobile = "+919530005050";
					if($mobile == "+91")
					{
						$mobile = "+919530005050";
					}

					$whatsapp_message = base64_encode($whatsapp_message);
					$this->db->query("insert into tbl_whatsapp_message (mobile,message,chemist_id) values ('$mobile','$whatsapp_message','$altercode')");
				}
			}
		}
	}
	
	public function create_invoice_excle(){
		
		$date = date("Y-m-d");
		/*$date = "2021-07-30";
		$vno = "177937";*/
		//"SELECT * FROM `tbl_invoice_test` WHERE vno = '$vno' ORDER BY id asc limit 1"
		$row = $this->db->query("SELECT * FROM `tbl_invoice` WHERE `date`='$date' and `status1`=0 and `deliverby`!='' ORDER BY id asc limit 1")->row();
		if($row->vdt!="")
		{
			$vdt 		= $row->vdt;
			$vno 		= $row->vno;
			$gstvno 	= $row->gstvno;
			$u_name 	= $row->name;
			$chemist_id = $row->chemist_id;
			$mobile 	= "+91".$row->mobile;
			$amt 		= $row->amt;
			$email_id 	= $row->email_id;
			$newdate 	= strtotime($row->vdt);
			$newdate 	= date('d-M-Y',$newdate);
			
			$this->db->query("update tbl_invoice set `status1`=1 where id='$row->id'");
			
			$file_name1  	= $file_name2  	= $file_name3  	= "";
			$file_name_1  	= $file_name_2  = $file_name_3  = "";
			
			$whatsapp_message_delete = "<br>All items in your order have been billed *without any shortage*";
			$delete_message = "<br>All items in your order have been billed <b>without any shortage</b>";
			$delete_query = $this->create_delete_invoice_query($vdt,$vno);
			$delete_query2 = $this->create_delete_invoice_query2($vdt,$vno);
			if(!empty($delete_query) || !empty($delete_query2))
			{
				$dt = $this->Excel_Model->create_delete_invoice_excle($gstvno,$delete_query,$delete_query2,"cronjob_download");
				$delete_message = $dt[1];
				$whatsapp_message_delete = $dt[2];
				
				$file_name2  = $dt[0];
				$file_name_2 = "delete_".$gstvno.".xls";
			}
			
			//die;
			$file_name_dt  = $this->Excel_Model->create_invoice_excle($vdt,$vno,$gstvno,$u_name,"cronjob_download");
			$file_name1 = $file_name_dt[0];
			$file_name_1 = $gstvno.".xls";
			$invoice_message_body = $file_name_dt[1]; 
			if($file_name_dt!="")
			{
				$link = "https://www.drdistributor.com/invoice/$chemist_id/$gstvno";
				$android_url = "https://rb.gy/xo2qlk";
				
				$subject = "Invoice No. $gstvno From D.R. Distributors Pvt. Ltd.";
				$message = "Hi $u_name ($chemist_id),<br><br>Invoice No. <b>$gstvno</b> for Order dated $newdate of the value around <b>Rs.$amt/-</b> has been generated by <b>D.R. Distributors Pvt. Ltd.</b>.<br><br>Please find the list of Items processed.<br><br>$invoice_message_body.$delete_message <br><br>You can check your invoice by clicking on <a href='$link'>$link</a>    <br><br>On laptop or pc you can visit following link to start placing orders https://rb.gy/alh73o <br><br>Please download our app from Google play store : <br><br><a href='$android_url'><img src='https://www.getmigo.com/coverage/us/tennessee/memphis/static/play-store-1cacd18258fc9c52bc3442564740d218.png' width='150px' height='50px'/></a><br><br>Please find the attatchment with this email.";
				//$message.= $row->memail;
				
				$subject = base64_encode($subject);
				$message = base64_encode($message);
				
				$user_email_id 		= $email_id;
				$email_other_bcc 	= "drdwebmail@gmail.com";
				if($email_id=="")
				{
					$user_email_id 	= "drdwebmail1@gmail.com";
				}
				
				$email_function = "invoice";

				$dt = array(
				'user_email_id'=>$user_email_id,
				'subject'=>$subject,
				'message'=>$message,
				'file_name1'=>$file_name1,
				'file_name_1'=>$file_name_1,
				'file_name2'=>$file_name2,
				'file_name_2'=>$file_name_2,
				'file_name3'=>$file_name3,
				'file_name_3'=>$file_name_3,
				'email_other_bcc'=>$email_other_bcc,
				'email_function'=>$email_function,
				);
				$this->Scheme_Model->insert_fun("tbl_email_send",$dt);

				/***************************whtsapp message *************************/				
				
				$whatsapp_message = "Hi $u_name ($chemist_id), <br><br>Invoice No. *$gstvno* for Order dated $newdate of the value around *Rs.$amt/-* has been generated by *D.R. Distributors Pvt. Ltd.*. $whatsapp_message_delete <br><br>You can check your invoice by clicking on $link <br><br>On laptop or pc you can visit following link to start placing orders https://rb.gy/alh73o <br><br>Please download our app from Google play store : $android_url";
				
				//$mobile = "+919530005050";
				if($mobile == "+91")
				{
					$mobile = "+919530005050";
				}
				$altercode = $chemist_id;
				$whatsapp_message = base64_encode($whatsapp_message);
				$this->db->query("insert into tbl_whatsapp_message (mobile,message,chemist_id) values ('$mobile','$whatsapp_message','$altercode')");
			}
		}
	}
	
	
	public function create_invoice_query($vdt='',$vno=''){
		if($vdt!='' && $vno!='')
		{
			$result = $this->mssql->query("select sl.vno,sl.vdt,sl.psrlno,sl.itemc,sl.batch,sl.qty,sl.fqty,sl.ntrate,sl.ftrate,sl.taxamt,sl.dis,sl.disamt,sl.netamt,sl.halfp,sl.mrp,sl.hsncode,sl.expiry,sl.scm1,sl.scm2,sl.scmper,sl.localcent,sl.excise,sl.cgst,sl.sgst,sl.igst,sl.adnlvat,sl.gdn,itm.compcode,itm.division,itm.name as item_name,itm.barcode as item_code,itm.pack as packing,itm.escode,sl.vtype,cmp.name as company_full_name from salepurchase2 as sl,item as itm left join company as cmp on cmp.code = itm.compcode where sl.vdt='$vdt' and sl.vno='$vno' and (sl.vtype='sb' or sl.vtype='sr') and sl.itemc = itm.code order by srlno asc")->result();
			return $result;
		}
	}
	
	public function create_delete_invoice_query($vdt='',$vno=''){
		if($vdt!='' && $vno!='')
		{
			$result = $this->mssql->query("select itemc,item.name as item_name,sp.vno,sp.vdt,slcd,amt,namt,remarks,descp from spalter as sp ,item where sp.vdt='$vdt' and vno='$vno' and (vtype='sb' or vtype='sr') and (descp='qty.change' or descp='item delete') and item.code=sp.itemc")->result();
			return $result;
		}
	}
	
	public function create_delete_invoice_query2($vdt='',$vno=''){
		if($vdt!='' && $vno!='')
		{
			$result = $this->mssql->query("select pordercount.odt as vdt,pordercount.purvno as vno,porder.itemc,item.name as item_name,porder.slcd,porder.qty as amt from pordercount,porder,item where pordercount.odt='$vdt' and pordercount.purvno='$vno' and pordercount.ordno = porder.ordno and porder.purvno='0' and item.code=porder.itemc")->result();
			return $result;
		}
	}
	
	public function total_invoice($value=''){
		$date = date("Y-m-d");
		if($value=="pickedby")
		{
			$value = "and pickedby=''";
		}
		if($value=="!pickedby")
		{
			$value = "and pickedby!=''";
		}
		if($value=="deliverby")
		{
			$value = "and deliverby='' and pickedby!=''";
		}
		if($value=="!deliverby")
		{
			$value = "and deliverby!='' and pickedby!=''";
		}
		$row = $this->mssql->query("select count(vdt) as total from salepurchase1extra where vdt='$date' $value")->row();
		return $row->total;
	}
	
	public function today_invoice_to_show($get,$value=""){
		$date = date("Y-m-d");
		if($value=="pickedby")
		{
			$value = "and pickedby=''";
		}
		if($value=="deliverby")
		{
			$value = "and deliverby='' and pickedby!=''";
		}
		
		if($get["invoice_no"]!="")
		{
			$value.= " and s2.gstvno='".$get["invoice_no"]."'";
		}
		
		if($get["location"]!="")
		{
			$value.= " and ms.altercode='".$get["location"]."'";
		}
		
		if($get["customer"]!="")
		{
			$value.= " and (a.altercode='".$get["customer"]."' or a.name like '%".$get["customer"]."%')";
		}
		
		if($get["pickedby"]!="")
		{
			$value.= " and pickedby like '%".$get["pickedby"]."%'";
		}
		
		if($get["deliverby"]!="")
		{
			$value.= " and deliverby like '%".$get["deliverby"]."%'";
		}
		
		$result = $this->mssql->query("select s2.personalmsg,mtime,ms.altercode as scode,sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile,dispatchtime from salepurchase1extra as sl,salepurchase1 as s2,acm as a,master as ms where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and ms.code=a.mstate and ms.slcd='st'and sl.vdt='$date' $value order by ms.altercode asc")->result();
		return $result;
	}
	
	public function check_order_sahi_insert_hoa_kya_nahi(){
		$row = $this->db->query("select distinct order_id,ordno_new from `tbl_order` where gstvno='' and ordno_new!='' ORDER BY RAND()")->row();
		if($row->order_id!="")
		{
			$uid = "drd-".$row->order_id;
			$ordno = $row->ordno_new;
			$row1 = $this->mssql->query("select ordno from pordercount where uid='$uid' and ordno='$ordno'")->row();
			if($row1->ordno=="")
			{
				echo $uid;
				echo "<br>";
				echo $row1->ordno;
				
				$json_url = constant('base_url2')."exe01/exe01/download_order_reset2/".$row->order_id;
				$ch = curl_init($json_url);
				$options = array(
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HTTPHEADER => array('Content-type: application/json'),
				);
				curl_setopt_array($ch,$options);
				$result = curl_exec($ch);
				//print_r($result);
				if($result=="ok")
				{
					$this->db->query("delete from tbl_order where order_id=$row->order_id");
				}
			}
		}
	}
	
	public function delivery_report($get){
		$date = date("Y-m-d");
		$where = "and sl.vdt='$date' ";
		if($get["from"]!="")
		{
			$date  = $get["from"];
			$where = "and sl.vdt>='$date' ";
		}
		if($get["to"]!="")
		{
			$date  = $get["to"];
			$where.= "and sl.vdt<='$date' ";
		}
		$result = $this->mssql->query("select sl.tagno,s2.amt,s2.personalmsg,mtime,ms.altercode as scode,sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile,dispatchtime from salepurchase1extra as sl,salepurchase1 as s2,acm as a,master as ms where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and ms.code=a.mstate and ms.slcd='st' $where order by sl.tagno asc")->result();
		return $result;
	}
	
	public function delivery_report_view($tagno="",$date=""){
		//$date = date("Y-m-d");
		$result = $this->mssql->query("select sl.tagno,s2.amt,s2.personalmsg,mtime,ms.altercode as scode,sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile,dispatchtime from salepurchase1extra as sl,salepurchase1 as s2,acm as a,master as ms where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and ms.code=a.mstate and ms.slcd='st'and sl.vdt='$date' and sl.tagno='$tagno' order by sl.tagno asc")->result();
		return $result;
	}
	
	public function drd_live_report($elements){
		
		$date = date("Y-m-d");
		$result = $this->mssql->query("select sl.tagno,s2.amt,s2.personalmsg,mtime,ms.altercode as scode,sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile,dispatchtime from salepurchase1extra as sl,salepurchase1 as s2,acm as a,master as ms where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and ms.code=a.mstate and ms.slcd='st'and sl.vdt='$date' and ms.altercode like '$elements%' order by ms.altercode asc")->result();
		return $result;
	}
	
	public function drd_live_report2($altercode){
		
		$date = date("Y-m-d");
		$result = $this->mssql->query("select sl.tagno,s2.amt,s2.personalmsg,mtime,ms.altercode as scode,sl.vdt,sl.vno,pickedby,checkedby,deliverby,vtype,s2.gstvno,a.altercode,a.name,a.mobile,dispatchtime from salepurchase1extra as sl,salepurchase1 as s2,acm as a,master as ms where a.code = s2.acno and sl.vdt = s2.vdt and sl.vno = s2.vno and (sl.vtype='sb' or sl.vtype='sr') and ms.code=a.mstate and ms.slcd='st'and sl.vdt='$date' and ms.altercode = '$altercode' and (pickedby='' or deliverby='')order by s2.gstvno asc,altercode asc")->result();
		return $result;
	}
}  